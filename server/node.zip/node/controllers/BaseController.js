"use strict";
/**
 * base class for controllers
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=BaseController.js.map