"use strict";
var SubscriberBusiness = require("../app/business/SubscriberBusiness");
var UserBusiness = require("../app/business/UserBusiness");
var SubscriberController = (function () {
    function SubscriberController() {
    }
    SubscriberController.prototype.getAgentDatabase = function (req, res) {
        var agentBusiness = new UserBusiness();
        var state = req.params.state;
        //console.log(req.params);
        var match = { state: state };
        var group = { _id: "$city", agents: { $sum: 1 } };
        agentBusiness.customaggregate("", match, group, function (error, result) {
            if (error) {
                console.log(error);
                res.send(error);
            }
            else {
                //	console.log(result)
                res.send({ agentDatabase: result });
            }
        });
    };
    ;
    SubscriberController.prototype.getSubsciberPreferences = function (req, res) {
        var subscriberBusiness = new SubscriberBusiness();
        var id = req.params.id;
        var query = { _id: id };
        var fields = {
            mailingLists: 1,
            agentTypes: 1,
            includeOutsideAreaProperties: 1,
            includeRentedProperties: 1,
            priceRanges: 1,
            propertyTypes: 1
        };
        subscriberBusiness.retrieveFields(query, fields, function (error, result) {
            if (error) {
                console.log(error);
                res.send(error);
            }
            else {
                //	console.log(result)
                res.send(result);
            }
        });
    };
    ;
    SubscriberController.prototype.create = function (req, res) {
        var subscriber = req.body;
        ;
        //	console.log(subscriber);
        subscriber.createdOn = new Date();
        var subscriberBusiness = new SubscriberBusiness();
        subscriber.status = "unverified";
        subscriberBusiness.create(subscriber, function (error, result) {
            //	console.log("res",result);
            if (error) {
                res.send(error);
            }
            else {
                res.send(result);
            }
        });
    };
    ;
    SubscriberController.prototype.retrieve = function (req, res) {
        //this._subscriberBusiness.retrieve()
    };
    return SubscriberController;
}());
module.exports = SubscriberController;
//# sourceMappingURL=SubscriberController.js.map