"use strict";
/**
 * api call lands here from routing
 */
var UserBusiness = require("./../app/business/UserBusiness");
var AdminUserBusiness = require("./../app/business/AdminUserBusiness");
var ContactformBusiness = require("./../app/business/ContactformBusiness");
var BlastBusiness = require("./../app/business/BlastBusiness");
var PropertyBusiness = require("./../app/business/PropertyBusiness");
var PaymentBusiness = require("./../app/business/PaymentBusiness");
var AgentTemplateBusiness = require("./../app/business/AgentTemplateBusiness");
var Common = require("./../config/constants/common");
var AgentBusiness = require("./../app/business/AgentBusiness");
var BlastImageBusiness = require("./../app/business/BlastImageBusiness");
var BlastSettingsBusiness = require("./../app/business/BlastSettingsBusiness");
var moment = require('moment');
var mammoth = require("mammoth");
var fs = require('fs');
var _ = require('underscore');
var mongoose = require('mongoose');
var async = require('async');
var base64Img = require('base64-img');
var stripe = require("stripe")(Common.STRIPESECRETKEY);
var UserController = (function () {
    function UserController() {
    }
    //being called by client getEmailExists
    UserController.prototype.getEmailExists = function (req, res) {
        try {
            var query = req.params.query;
            var _userBusiness = new UserBusiness();
            _userBusiness.count({ 'email': { $regex: "^" + (query.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')) + "$", $options: "i" } }, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": "error" });
                }
                else {
                    res.send(JSON.stringify(result));
                }
                ;
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.register = function (req, res) {
        try {
            var user = req.body.user;
            user.createdOn = new Date();
            user.password = req.body.user.password;
            user.firstName = req.body.user.firstName.toLowerCase();
            user.roles = 'agents';
            user.lastName = req.body.user.lastName.toLowerCase();
            user.paidOn = false;
            user.isDeleted = false;
            var userBusiness = new UserBusiness();
            var token = userBusiness.createToken(user);
            userBusiness.create(user, function (error, userdata) {
                if (error) {
                    console.log("error==sss==", error);
                    res.send({
                        "error": error
                    });
                }
                else {
                    var signupemailtemplatetouser = Common.SIGNUP_EMAIL_TEMPLATE_TO_REGISTERED_USER;
                    var emailtemplate = signupemailtemplatetouser.replace(/#email#/g, userdata.email).replace(/#password#/g, userdata.password);
                    Common.sendMail(userdata.email, Common.ADMIN_EMAIL, 'Welcome to ListingReach!', null, emailtemplate, function (error, response) {
                        if (error) {
                            res.send("error");
                        }
                        else {
                            res.send({ "success": "success" });
                        }
                    });
                    res.send({ "success": "success" });
                }
            });
        }
        catch (e) {
            res.send({
                "error": "error in your request"
            });
        }
    };
    UserController.prototype.authenticate = function (req, res) {
        try {
            var _user = req.body;
            //set the createdon to now
            var _userBusiness = new UserBusiness();
            _userBusiness.findOne({ email: _user.email }, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    if (result && result.password && result.password == _user.password) {
                        if (result.isDeleted && result.isDeleted === true) {
                            return res.status(401).send({ "error": "Your account is no longer available. Please contact admin." });
                        }
                        else {
                            if (result.status == 'unverified') {
                                return res.status(401).send({ "error": "Your account is not active. Please contact admin." });
                            }
                            else {
                                var token = _userBusiness.createToken(result);
                                var _updateData = req.body;
                                _updateData.lastLogin = new Date();
                                _updateData.token = token;
                                var _id = result._id.toString();
                                var _userBusinessUpdate = new UserBusiness();
                                _userBusinessUpdate.update(_id, _updateData, function (error, resultUpdate) {
                                    if (error)
                                        res.send({ "error": "error", "message": "Authentication error" }); //res.status(401).send({"error": "Authentication error"});
                                    else {
                                        res.send({
                                            userId: result._id,
                                            email: result.email,
                                            firstName: result.firstName,
                                            lastName: result.lastName,
                                            token: token,
                                            roles: result.roles
                                        });
                                    }
                                });
                            }
                        }
                    }
                    else {
                        return res.status(401).send({ "error": "The username or password don't match" });
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.create = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                var _user = req.body;
                _user.createdOn = new Date();
                var _userBusiness = new UserBusiness();
                _userBusiness.create(_user, function (error, result) {
                    if (error) {
                        res.send({ "error": error });
                    }
                    else
                        res.send({ "success": "success" });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.updateStatus = function (req, res) {
        try {
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.updateUser = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (UserData) {
                var _user = req.body.user;
                var _id = _user.id.toString();
                _userBusiness.update(mongoose.Types.ObjectId(_id), _user, function (error, userdata) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": error });
                    }
                    else {
                        var _agentBusiness = new AgentBusiness();
                        async.parallel({
                            agentData: function (callback) {
                                _agentBusiness.findOne({ 'userId': _id }, function (error, agentdata) {
                                    if (error) {
                                    }
                                    else {
                                        callback(null, agentdata);
                                    }
                                });
                            },
                            userData: function (callback) {
                                _userBusiness.retrieve({ _id: _id }, function (error, result) {
                                    var returnObj = result.map(function (obj) {
                                        return {
                                            id: obj._id,
                                            userName: obj.userName,
                                            firstName: obj.firstName,
                                            lastName: obj.lastName,
                                            status: obj.status,
                                            email: obj.email,
                                            companyName: obj.companyName,
                                            phone: obj.phone,
                                            city: obj.city,
                                            zipcode: obj.zipcode,
                                            roles: obj.roles
                                        };
                                    });
                                    callback(null, returnObj);
                                });
                            }
                        }, function (err, results) {
                            if (err) {
                                res.send({ "error": "error" });
                            }
                            res.json({ "status": "success", "data": results });
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.updateprofilepic = function (data, id, res, flag) {
        var _agentBusiness = new AgentBusiness();
        var _agent = data;
        _agent.createdOn = new Date();
        var type = data.mimetype.split("/");
        var userid = id.toString();
        var _id = userid;
        _agent.userId = userid;
        if (flag == 'logo') {
            _agent.logo_url = data.filename;
        }
        else {
            _agent.image_url = data.filename;
        }
        _agentBusiness.findOne({ 'userId': userid }, function (error, agentresult) {
            if (agentresult != null) {
                var _id = agentresult._id.toString();
                _agentBusiness.update(_id, _agent, function (error, resultUpdate) {
                    if (error) {
                    }
                    else {
                        return res.json({ profileimg: agentresult.profilePic });
                    }
                });
            }
            else {
                _agentBusiness.create(_agent, function (error, agentresultData) {
                    if (error) {
                    }
                    else {
                        return res.json({ profileimg: agentresultData.image_url });
                    }
                });
            }
        });
    };
    UserController.prototype.delete = function (req, res) {
        try {
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.retrieve = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                _userBusiness.retrieve(req.body, function (error, result) {
                    if (error)
                        res.send({ "error": "error" });
                    else
                        res.send(result);
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.findById = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            var _agentBusiness = new AgentBusiness();
            var _balstimageBusiness = new BlastImageBusiness();
            _userBusiness.verifyToken(req, res, function (userdata) {
                async.parallel({
                    agentData: function (callback) {
                        _agentBusiness.retrieve({ 'userId': userdata.id }, function (error, agentdata) {
                            if (error) {
                            }
                            else {
                                var returnObjagent = agentdata.map(function (obj) {
                                    return {
                                        id: obj._id,
                                        name: obj.name,
                                        email: obj.website_url,
                                        designation: obj.designation,
                                        website_url: obj.website_url,
                                        phone_number: obj.phone_number,
                                        company_details: obj.company_details,
                                        other_information: obj.other_information,
                                        image_url: obj.image_url,
                                        logo_url: obj.logo_url
                                    };
                                });
                                callback(null, returnObjagent);
                            }
                        });
                    },
                    imageData: function (callback) {
                        _balstimageBusiness.retrieve({ 'user_id': userdata.id }, function (error, imagedata) {
                            if (error) {
                            }
                            else {
                                var returnObjimage = imagedata.map(function (obj) {
                                    return {
                                        id: obj._id,
                                        url: obj.url,
                                    };
                                });
                                callback(null, returnObjimage);
                            }
                        });
                    },
                    userData: function (callback) {
                        _userBusiness.retrieve({ _id: userdata.id }, function (error, result) {
                            var returnObj = result.map(function (obj) {
                                return {
                                    id: obj._id,
                                    userName: obj.userName,
                                    firstName: obj.firstName,
                                    lastName: obj.lastName,
                                    status: obj.status,
                                    email: obj.email,
                                    companyName: obj.companyName,
                                    phone: obj.phone,
                                    city: obj.city,
                                    zipcode: obj.zipcode,
                                    roles: obj.roles,
                                    state: obj.state
                                };
                            });
                            callback(null, returnObj);
                        });
                    }
                }, function (err, results) {
                    if (err) {
                        res.send({ "error": "error" });
                    }
                    res.json({ "status": "success", "data": results });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.findByToken = function (req, res) {
        var _userBusiness = new UserBusiness();
        _userBusiness.verifyToken(req, res, function (UserData) {
            res.send(UserData);
        });
    };
    UserController.prototype.contactForm = function (req, res) {
        try {
            var _contactform = req.body;
            var _contactformBusiness = new ContactformBusiness();
            _contactform.fullname = req.body.fullname;
            _contactform.email = req.body.email;
            _contactform.phone = req.body.phone;
            _contactform.message = req.body.message;
            _contactform.createdOn = new Date();
            _contactformBusiness.create(_contactform, function (error, result) {
                if (error) {
                    res.send({ "error=========": error });
                }
                else {
                    var contactFormemail = Common.CONTACT_FORM;
                    var emailtemplate = contactFormemail.replace(/#fullname#/g, _contactform.fullname).replace(/#email#/g, _contactform.email).replace(/#phone#/g, _contactform.phone).replace(/#message#/g, _contactform.message).replace(/#date#/g, _contactform.createdOn);
                    Common.sendMail(_contactform.email, 'support@ListingReach.com', 'Contact Form', null, emailtemplate, function (error, response) {
                        if (error) {
                            res.end("error");
                        }
                    });
                    res.status(201).send({ "success": "done" });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.emailPreviewTemplate = function (req, res) {
        try {
            var _propertyData = req.body;
            var property = _propertyData.property_details;
            var _contactformBusiness = new ContactformBusiness();
            property.email = req.body.email;
            var _propertyformsEmail = {};
            var subject = property[0].templates[0].email_subject;
            var formLine = property[0].templates[0].from_line;
            var formReply = property[0].templates[0].address;
            var headline = property[0].templates[0].headline;
            var agentData = property[0].agentData[0].agentData;
            if (property && property.length > 1) {
                var html = '';
                property.forEach(function (proDta) {
                    html += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;\">\n\t\t\t                     <div class=\"row\" style=\"display: block;display: flex;flex-wrap: wrap;border-top: 2px solid #ccc;\">\n\t\t\t                        <div style=\"width:50%;display: block; background:#f1f1f1;height: 400px;\">\n\t\t\t                           <img src=\"http://66.235.194.119/listingreach/img/img4.jpg\" alt=\"image\" style=\"width:100%;height: 400px;\">\n\t\t\t                        </div>";
                    html += "<div style=\"width:50%;display: block; background:#f1f1f1; height: 400px;\">\n\t\t\t                           <div class=\"row\" style=\"display: flex;flex-wrap: wrap;\">\n\t\t\t                              <div style=\"width:100%;margin-bottom: 1rem !important; margin-left: 1rem !important;margin-top: 1rem !important;\">\n\t\t\t                                 <h4 style=\" background: #f1f1f1;font-size: 1.5rem;margin-top: 0;\n\t\t\t                                    margin-bottom: 1rem;\">Price: " + proDta.price + " per Square Foot</h4>\n\t\t\t                              </div>\n\t\t\t                              <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                                 <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                    font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Key Features:</label>\n\t\t\t                                 <ul>\n\t\t\t                                    <li>Property Type: " + proDta.property_type + "  </li>\n\t\t\t                                    <li>Property Style: " + proDta.property_style + "  </li>\n\t\t\t                                    <li> " + proDta.number_bedrooms + " Bedrooms</li>\n\t\t\t                                    <li>" + proDta.number_bathrooms[0].full + " Full " + proDta.number_bathrooms[0].half + " Half Bathrooms</li>\n\t\t\t                                    <li>1 Full +2 Half Bathrooms</li>\n\t\t\t                                    <li>" + proDta.building_size + " square feet</li>\n\t\t\t                                    <li>" + proDta.price + "  /sqft</li>\n\t\t\t                                    <li>Lot Size: " + proDta.lot_size + " sqft</li>\n\t\t\t                                    <li>  Built " + proDta.year_built + " </li>\n\t\t\t                                    <li>" + proDta.garageSize + " Garage</li>\n\t\t\t                                    <li> " + proDta.number_stories + " </li>\n\t\t\t                                 </ul>\n\t\t\t                              </div>\n\t\t\t                           </div>\n\t\t\t                        </div>\n\t\t\t                     </div>";
                    html += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;border-bottom: 2px solid #ccc; padding-top:30px;\">\n\t\t\t                        <div class=\"row\">\n\t\t\t                           <div class=\"mt-3 text-center\" style=\"width:100%;margin-top: 1rem !important;text-align: center !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Address:</label>\n\t\t\t                              <p>" + proDta.street_address + ", " + proDta.city + ", " + proDta.zipcode + "</p>\n\t\t\t                           </div>";
                    proDta.isOpenHouse.forEach(function (resut) {
                        html += "<div class=\"text-center\" style=\"width:100%;text-align: center !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">" + resut.openHouseData.houseType + ":</label>\n\t\t\t                              <span>" + resut.openHouseData.date + " " + resut.openHouseData.startTime + "  - " + resut.openHouseData.endTime + " </span><br>\n\t\t\t                           </div>";
                    });
                    html += "<div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">MLS#:</label>\n\t\t\t                              <span>" + proDta.mls_number + "</span>\n\t\t\t                           </div>\n\t\t\t                           <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Description:</label>\n\t\t\t                              <span>" + proDta.property_details + "</span>         \n\t\t\t                           </div>\n\t\t\t                           <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Links:</label>";
                    proDta.isOpenHouse.forEach(function (resut) {
                        html += "<br><a href=\"http://66.235.194.119/listingreach\" style=\"color: #000000;transition: all .5s ease;\"><u> Websitename with hyperlink</a></u>";
                    });
                    html += " </div>\n\t\t\t                        </div>\n\t\t\t                     </div>\n\t\t\t\t\t\t\t</div>";
                });
                var previewTemplatememail = Common.PREVIEW_EMAIL_MULTIPROPERTY_TEMPLATE;
                var emailtemplate = previewTemplatememail
                    .replace(/#multiproperty#/g, html)
                    .replace(/#agentName#/g, agentData.name)
                    .replace(/#agentEmail#/g, agentData.Email)
                    .replace(/#agentImage#/g, agentData.image_url || "http://66.235.194.119/listingreach/img/dummy-profile.png")
                    .replace(/#companyLogo#/g, agentData.logo_url || "http://66.235.194.119/listingreach/img/dummy-logo.png")
                    .replace(/#WebsiteUrl#/g, agentData.website_url)
                    .replace(/#phone_number#/g, agentData.phone_number)
                    .replace(/#companyDetail#/g, agentData.company_details)
                    .replace(/#subject#/g, subject)
                    .replace(/#formLine#/g, formLine)
                    .replace(/#formReply#/g, formReply)
                    .replace(/#blastHeadline#/g, headline);
                Common.sendMail(property.email, 'support@employeemirror.com', 'Property Details', null, emailtemplate, function (error, response) {
                    if (error) {
                        console.log(error);
                        res.end("error");
                    }
                });
                res.status(201).send({ "success": "done" });
            }
            else {
                var html = '';
                property.forEach(function (proDta) {
                    html += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;\">\n\t\t\t                     <div class=\"row\" style=\"display: block;display: flex;flex-wrap: wrap;border-top: 2px solid #ccc;\">\n\t\t\t                        <div style=\"width:50%;display: block; background:#f1f1f1;height: 400px;\">\n\t\t\t                           <img src=\"http://66.235.194.119/listingreach/img/img4.jpg\" alt=\"image\" style=\"width:100%;height: 400px;\">\n\t\t\t                        </div>";
                    html += "<div style=\"width:50%;display: block; background:#f1f1f1; height: 400px;\">\n\t\t\t                           <div class=\"row\" style=\"display: flex;flex-wrap: wrap;\">\n\t\t\t                              <div style=\"width:100%;margin-bottom: 1rem !important; margin-left: 1rem !important;margin-top: 1rem !important;\">\n\t\t\t                                 <h4 style=\" background: #f1f1f1;font-size: 1.5rem;margin-top: 0;\n\t\t\t                                    margin-bottom: 1rem;\">Price: " + proDta.price + " per Square Foot</h4>\n\t\t\t                              </div>\n\t\t\t                              <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                                 <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                    font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Key Features:</label>\n\t\t\t                                 <ul>\n\t\t\t                                    <li>Property Type: " + proDta.property_type + "  </li>\n\t\t\t                                    <li>Property Style: " + proDta.property_style + "  </li>\n\t\t\t                                    <li> " + proDta.number_bedrooms + " Bedrooms</li>\n\t\t\t                                    <li>" + proDta.number_bathrooms[0].full + " Full " + proDta.number_bathrooms[0].half + " Half Bathrooms</li>\n\t\t\t                                    <li>1 Full +2 Half Bathrooms</li>\n\t\t\t                                    <li>" + proDta.building_size + " square feet</li>\n\t\t\t                                    <li>" + proDta.price + "  /sqft</li>\n\t\t\t                                    <li>Lot Size: " + proDta.lot_size + " sqft</li>\n\t\t\t                                    <li>  Built " + proDta.year_built + " </li>\n\t\t\t                                    <li>" + proDta.garageSize + " Garage</li>\n\t\t\t                                    <li> " + proDta.number_stories + " </li>\n\t\t\t                                 </ul>\n\t\t\t                              </div>\n\t\t\t                           </div>\n\t\t\t                        </div>\n\t\t\t                     </div>";
                    html += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;border-bottom: 2px solid #ccc; padding-top:30px;\">\n\t\t\t                        <div class=\"row\">\n\t\t\t                           <div class=\"mt-3 text-center\" style=\"width:100%;margin-top: 1rem !important;text-align: center !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Address:</label>\n\t\t\t                              <p>" + proDta.street_address + ", " + proDta.city + ", " + proDta.zipcode + "</p>\n\t\t\t                           </div>";
                    proDta.isOpenHouse.forEach(function (resut) {
                        html += "<div class=\"text-center\" style=\"width:100%;text-align: center !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">" + resut.openHouseData.houseType + ":</label>\n\t\t\t                              <span>" + resut.openHouseData.date + " " + resut.openHouseData.startTime + "  - " + resut.openHouseData.endTime + " </span><br>\n\t\t\t                           </div>";
                    });
                    html += "<div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">MLS#:</label>\n\t\t\t                              <span>" + proDta.mls_number + "</span>\n\t\t\t                           </div>\n\t\t\t                           <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Description:</label>\n\t\t\t                              <span>" + proDta.property_details + "</span>         \n\t\t\t                           </div>\n\t\t\t                           <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n\t\t\t                              <label class=\"flyer-label\" style=\"color: #EE8C3A;\n\t\t\t                                 font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Links:</label>";
                    proDta.isOpenHouse.forEach(function (resut) {
                        html += "<br><a href=\"http://66.235.194.119/listingreach\" style=\"color: #000000;transition: all .5s ease;\"><u> Websitename with hyperlink</a></u>";
                    });
                    html += " </div>\n\t\t\t                        </div>\n\t\t\t                     </div>\n\t\t\t\t\t\t\t</div>";
                });
                var previewTemplatememail = Common.PREVIEW_EMAIL_MULTIPROPERTY_TEMPLATE;
                var emailtemplate = previewTemplatememail
                    .replace(/#multiproperty#/g, html)
                    .replace(/#agentName#/g, agentData.name)
                    .replace(/#agentEmail#/g, agentData.Email)
                    .replace(/#agentImage#/g, agentData.image_url || "http://66.235.194.119/listingreach/img/dummy-profile.png")
                    .replace(/#companyLogo#/g, agentData.logo_url)
                    .replace(/#WebsiteUrl#/g, agentData.website_url)
                    .replace(/#subject#/g, subject)
                    .replace(/#formLine#/g, formLine)
                    .replace(/#formReply#/g, formReply)
                    .replace(/#blastHeadline#/g, headline);
                Common.sendMail(property.email, 'support@employeemirror.com', 'Property Details', null, emailtemplate, function (error, response) {
                    if (error) {
                        console.log(error);
                        res.end("error");
                    }
                });
                res.status(201).send({ "success": "done" });
            }
            {
                var openData_1 = '';
                if (property[0].isOpenHouse.openHouseData != undefined && property[0].isOpenHouse.openHouseData.length) {
                    var houseArray = property[0].isOpenHouse.openHouseData;
                    //console.log("houseArray===",houseArray);
                    houseArray.forEach(function (item) {
                        openData_1 += "<div>\n\t\t\t\t <label class=\"flyer-label\">" + item.openHouseData.houseType + ":</label>\n\t\t\t\t <span>" + item.openHouseData.date + " " + item.openHouseData.startTime + "  - " + item.openHouseData.endTime + "</span><br>\n\t\t\t\t </div>";
                    });
                }
                var links_1 = '';
                if (property[0].linksToWebsites.linkData != undefined && property[0].linksToWebsites.linkData.length) {
                    var linkArray = property[0].linksToWebsites.linkData;
                    linkArray.forEach(function (item) {
                        links_1 += "<div>\n\t\t\t\t  <label class=\"flyer-label\">Links:</label>\n \t\t\t\t\t<p><a href=\"#\"><u> " + item.linksToWebsiteData.buildingSize + "</a></u></p><br>\n\t\t\t\t </div>";
                    });
                }
                var previewTemplatememail = Common.PREVIEW_EMAIL_TEMPLATE;
                var emailtemplate = previewTemplatememail
                    .replace(/#subject#/g, subject)
                    .replace(/#formLine#/g, formLine)
                    .replace(/#formReply#/g, formReply)
                    .replace(/#blastHeadline#/g, headline)
                    .replace(/#numberOfBedrooms#/g, property[0].numberOfBedrooms)
                    .replace(/#propertyDetail#/g, property[0].propertyDetail)
                    .replace(/#mlsNumber#/g, property[0].mlsNumber)
                    .replace(/#streetAddress#/g, property[0].streetAddress)
                    .replace(/#zipCode#/g, property[0].zipCode)
                    .replace(/#city#/g, property[0].city)
                    .replace(/#pricePerSquareFoot#/g, property[0].pricePerSquareFoot)
                    .replace(/#yearBuilt#/g, property[0].yearBuilt)
                    .replace(/#lotSize#/g, property[0].lotSize)
                    .replace(/#openData#/g, openData_1)
                    .replace(/#links#/g, links_1)
                    .replace(/#propertyType#/g, property[0].propertyType)
                    .replace(/#full#/g, property[0].number_bathrooms[0].full)
                    .replace(/#half#/g, property[0].number_bathrooms[0].half)
                    .replace(/#garageSize#/g, property[0].garageSize)
                    .replace(/#propertyStyle#/g, property[0].propertyStyle)
                    .replace(/#numberOfStories#/g, property[0].numberOfStories)
                    .replace(/#agentName#/g, agentData.name)
                    .replace(/#agentEmail#/g, agentData.Email)
                    .replace(/#agentImage#/g, agentData.image_url || "http://66.235.194.119/listingreach/img/dummy-profile.png")
                    .replace(/#companyLogo#/g, agentData.logo_url || "http://66.235.194.119/listingreach/img/dummy-logo.png")
                    .replace(/#WebsiteUrl#/g, agentData.website_url)
                    .replace(/#phone_number#/g, agentData.phone_number)
                    .replace(/#companyDetail#/g, agentData.company_details);
                Common.sendMail(property.email, 'support@employeemirror.com', 'Property Details', null, emailtemplate, function (error, response) {
                    if (error) {
                        console.log(error);
                        res.end("error");
                    }
                });
                res.status(201).send({ "success": "done" });
            }
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.forgetUserPassword = function (req, res) {
        try {
            var _user = req.body;
            var _userBusiness = new UserBusiness();
            _userBusiness.findOne({ email: _user.email }, function (error, result) {
                if (error) {
                    res.send({ "error": "error" });
                }
                else {
                    if (result && result.email == _user.email) {
                        if (result.status == 'unverified') {
                            return res.status(401).send({ "error": "Your account is not verified. Please contact admin." });
                        }
                        else {
                            var token = _userBusiness.createToken(result);
                            var _updateData = req.body;
                            _updateData.lastLogin = new Date();
                            _updateData.token = token;
                            var _id = result._id.toString();
                            var _userBusinessUpdate = new UserBusiness();
                            // Generate new password ...
                            var autoGeneratedPassword = Math.random().toString(36).slice(-8);
                            _user.password = 'P' + autoGeneratedPassword;
                            _userBusinessUpdate.update(_id, _updateData, function (error, resultUpdate) {
                                if (error)
                                    res.send({ "error": "error", "message": "Authentication error" }); //res.status(401).send({"error": "Authentication error"});
                                else {
                                    var _userBusiness = new UserBusiness();
                                    _userBusiness.findById(_id, function (error, resultuser) {
                                        if (error)
                                            res.send({ "error": "error", "message": "Authentication error" });
                                        else {
                                            var emailresetpassword = Common.EMAIL_TEMPLATE_RESET_USER_PASSWORD;
                                            var emailtemplate = emailresetpassword.replace(/#password#/g, _user.password);
                                            Common.sendMail(result.email, 'support@ListingReach.com', 'Forgot Password', null, emailtemplate, function (error, response) {
                                                if (error) {
                                                    console.log(error);
                                                    res.end("error");
                                                }
                                            });
                                            res.status(201).send({ "success": "done" });
                                        }
                                    });
                                }
                            });
                        }
                    }
                    else {
                        return res.status(401).send({ "error": "You have entered invalid email." });
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.UpdateUserPassword = function (req, res) {
        try {
            var _user = req.body;
            var _userBusiness = new UserBusiness();
            var _idc = req.body.user;
            _user.password = req.body.newpassword;
            _userBusiness.findOne({ _id: _idc, password: req.body.currentpassword }, function (error, result) {
                if (error) {
                    res.send({ "error": "Please enter current vaild password." });
                }
                else if (result == null) {
                    res.send({ "error": "Please enter current vaild password." });
                }
                else {
                    _user.password = req.body.newpassword;
                    _userBusiness.update(_idc, _user, function (error, resultUpdate) {
                        if (error)
                            res.send({ "error": "error", "message": "Your password is not updated." });
                        else {
                            res.status(201).send({ "success": "Your password is successfully updated." });
                        }
                    });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.selectDatabase = function (req, res) {
        try {
            var _blastform = req.body;
            var _id = _blastform.blast_id;
            var _blastBusiness = new BlastBusiness();
            //console.log("_blastform=====",_blastform);
            /*					if(property.isOpenHouse){
                                    var opneHouseData=[];
                                    let data = property.isOpenHouse.openHouseData;
                                                data.forEach(function(house:any) {
                                                if(house){
                                                    opneHouseData.push({openHouseData:house.openHouseData});
                                                }
                                            });
                                   _propertyform.isOpenHouse=opneHouseData;
                            }*/
            _blastBusiness.update(_id, _blastform, function (error, resultUpdate) {
                if (error) {
                    res.send({ "error": "error" });
                }
                else {
                    res.send({ "success": "success" });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.forgetSAdminPassword = function (req, res) {
        try {
            var _user = req.body;
            var _adminUserBusiness = new AdminUserBusiness();
            var _userBusiness = new UserBusiness();
            _adminUserBusiness.findOne({ email: _user.email }, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    if (result && result.email == _user.email) {
                        if (!result.isActive) {
                            return res.status(401).send({ "error": "Your account is not active. Please contact admin." });
                        }
                        else {
                            var token = _userBusiness.createToken(result);
                            var _updateAdminData = req.body;
                            _updateAdminData.lastLogin = new Date();
                            _updateAdminData.token = token;
                            var _id = result._id.toString();
                            var _adminUserBusiness = new AdminUserBusiness();
                            // Generate new password ...
                            var autoGeneratedPassword = Math.random().toString(36).slice(-8);
                            _user.password = 'P' + autoGeneratedPassword;
                            _adminUserBusiness.update(_id, _updateAdminData, function (error, resultUpdate) {
                                if (error)
                                    res.send({ "error": "error", "message": "Authentication error" }); //res.status(401).send({"error": "Authentication error"});
                                else {
                                    var companyId = result._id;
                                    _adminUserBusiness.retrieve(companyId, function (error, resultCompany) {
                                        if (error)
                                            res.send({ "error": "error", "message": "Authentication error" });
                                        else {
                                            var emailresetpassword = Common.EMAIL_TEMPLATE_RESET_ADMIN_PASSWORD;
                                            var emailtemplate = emailresetpassword.replace(/#password#/g, _user.password);
                                            Common.sendMail(result.email, 'support@inteleagent.com', 'Forgot Password', null, emailtemplate, function (error, response) {
                                                if (error) {
                                                    console.log(error);
                                                    res.end("error");
                                                }
                                            });
                                            res.status(201).send({ "success": "done" });
                                        }
                                    });
                                }
                            });
                        }
                    }
                    else {
                        return res.status(401).send({ "error": "Invalid email." });
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.verifytoken = function (req, res) {
        var _userBusiness = new UserBusiness();
        _userBusiness.verifyToken(req, res, function (userData) {
            res.status(201).send({
                token: "valid"
            });
        });
    };
    //tbd split the incoming query to be {a:b} instead of a=b
    UserController.prototype.count = function (req, res) {
        try {
            var query = req.params.query;
            var _userBusiness = new UserBusiness();
            _userBusiness.count(query, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": "error" });
                }
                else {
                    res.send(result);
                }
                ;
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getReferences = function (req, res) {
        try {
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveBlast = function (req, res) {
        try {
            var _blastform = req.body;
            var _blastBusiness = new BlastBusiness();
            _blastform.status = ' ';
            _blastform.selected_template_date = new Date();
            _blastBusiness.create(_blastform, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": error });
                }
                else
                    res.send({ "success": "success", data: result });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveDesignTemplate = function (req, res) {
        try {
            var _IagentTemplateModel_1 = req.body;
            var _agentTemplateBusiness = new AgentTemplateBusiness();
            var _blastform_1 = req.body;
            var _blastBusiness_1 = new BlastBusiness();
            _blastform_1.selected_template_date = new Date();
            _agentTemplateBusiness.create(_IagentTemplateModel_1, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": error });
                }
                else {
                    if (result && result._id) {
                        _blastform_1.selected_template_id = result._id;
                        _blastform_1.status = 'Draft';
                        _blastBusiness_1.findOne({ "user_id": _IagentTemplateModel_1.userId }, function (error, user) {
                            var _id = user._id.toString();
                            _blastBusiness_1.update(_id, _blastform_1, function (error, resultUpdate) {
                                if (error) {
                                }
                                else {
                                    return res.json({ "sucess": "sucess", "data": result });
                                }
                            });
                        });
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveAgents = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                var _agent = req.body;
                _agent.createdOn = new Date();
                _agent.user_id = companyUserData._id;
                var _agentBusiness = new AgentBusiness();
                _agentBusiness.findOne({ 'userId': userData._id }, function (error, agentresult) {
                    if (agentresult) {
                        var _id = agentresult._id.toString();
                        _agentBusiness.update(_id, _agent, function (error, resultUpdate) {
                            if (error) {
                            }
                            else {
                                res.status(201).send({ "success": "Your agent info successfully updated." });
                                return res.json({ data: resultUpdate });
                            }
                        });
                    }
                    else {
                        _agentBusiness.create(_agent, function (error, agentresultData) {
                            if (error) {
                                console.log("error====", error);
                            }
                            else {
                                res.status(201).send({ "success": "Your agent info successfully updated." });
                            }
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveProperty = function (req, res) {
        try {
            var _propertyforms = req.body;
            var _propertyBusiness = new PropertyBusiness();
            if (_propertyforms && _propertyforms.property && _propertyforms.property.length) {
                var _templateforms = req.body;
                var _templateBusiness = new AgentTemplateBusiness();
                var _blastform = req.body;
                var _blastBusiness = new BlastBusiness();
                var _templateform_1 = {};
                _propertyforms.property.forEach(function (property) {
                    var _propertyform = {};
                    _templateform_1.email_subject = _templateforms.Email.formSubject;
                    _templateform_1.from_line = _templateforms.Email.formLine;
                    _templateform_1.address = _templateforms.Email.formReply;
                    _templateform_1.headline = _templateforms.blastHeadline;
                    _propertyform.display_method = property.propertyAddress.displayMethod;
                    _propertyform.blast_id = _propertyforms.blast_id;
                    _propertyform.street_address = property.propertyAddress.streetAddress;
                    _propertyform.city = property.propertyAddress.city;
                    _propertyform.state = property.propertyAddress.state;
                    _propertyform.zipcode = property.propertyAddress.zipCode;
                    _propertyform.userId = property.userId;
                    _propertyform.mls_number = property.mlsNumber.numberProperty;
                    _propertyform.board = property.mlsNumber.boardAssociation;
                    _propertyform.pricingInfo = property.pricingInfo;
                    if (property.linksToWebsites) {
                        var linksData = [];
                        var data = property.linksToWebsites.linkData;
                        data.forEach(function (links) {
                            if (links) {
                                linksData.push({ linksToWebsiteData: links.linksToWebsiteData });
                            }
                        });
                        _propertyform.linksToWebsites = linksData;
                    }
                    if (property.isOpenHouse) {
                        var opneHouseData = [];
                        var data = property.isOpenHouse.openHouseData;
                        data.forEach(function (house) {
                            if (house) {
                                opneHouseData.push({ openHouseData: house.openHouseData });
                            }
                        });
                        _propertyform.isOpenHouse = opneHouseData;
                    }
                    if (property.propertyImages) {
                        var propertyImages = [];
                        var data = property.propertyImages.img;
                        data.forEach(function (images) {
                            if (images) {
                                propertyImages.push({ imageId: images.id, imageUrl: images.imgUrl });
                            }
                        });
                        _propertyform.propertyImages = propertyImages;
                    }
                    _propertyform.property_type = property.generalPropertyInformation.propertyType;
                    _propertyform.property_style = property.generalPropertyInformation.propertyStyle;
                    _propertyform.lot_size = property.generalPropertyInformation.lotSize;
                    _propertyform.number_bedrooms = property.generalPropertyInformation.numberOfBedrooms;
                    _propertyform.building_size = property.generalPropertyInformation.buildingSize;
                    _propertyform.number_stories = property.generalPropertyInformation.numberOfStories;
                    _propertyform.number_bathrooms = property.generalPropertyInformation.numberOfBathrooms;
                    _propertyform.year_built = property.generalPropertyInformation.yearBuilt;
                    _propertyform.garage = property.generalPropertyInformation.garage;
                    _propertyform.garageSize = property.generalPropertyInformation.garageSize;
                    _propertyform.price = property.generalPropertyInformation.pricePerSquareFoot;
                    _propertyform.property_details = property.propertyDetail;
                    _propertyBusiness.create(_propertyform, function (error, result) {
                        if (error) {
                            console.log(error);
                            res.send({ "error": error });
                        }
                        _templateform_1.Property_id = result._id.toString();
                        //console.log("3434343====",result._id.toString());
                        var _id = _templateforms.templateId;
                        _templateBusiness.update(_id, _templateform_1, function (error, resultUpdate) {
                            if (error) {
                                console.log(error);
                                res.send({ "error": error });
                            }
                            else {
                                var _blastforms = {};
                                var _id_1 = _blastform.blast_id;
                                if (_blastform && _blastform.agentData != undefined) {
                                    _blastforms.agentData = _blastform.agentData;
                                    _blastBusiness.update(_id_1, _blastforms, function (error, blastUpadte) {
                                        if (error) {
                                            res.send({ "error": error });
                                        }
                                        var propertyAggregate = [
                                            {
                                                $lookup: {
                                                    from: "users",
                                                    localField: "userId",
                                                    foreignField: "_id",
                                                    as: "users"
                                                }
                                            },
                                            {
                                                $unwind: "$users"
                                            },
                                            {
                                                $lookup: {
                                                    from: "templates",
                                                    localField: "_id",
                                                    foreignField: "Property_id",
                                                    as: "templates"
                                                }
                                            },
                                            {
                                                $lookup: {
                                                    from: "blasts",
                                                    localField: "blast_id",
                                                    foreignField: "_id",
                                                    as: "blasts"
                                                }
                                            },
                                            {
                                                $project: {
                                                    "_id": 1,
                                                    "userId": 1,
                                                    "display_method": 1,
                                                    "street_address": 1,
                                                    "city": 1,
                                                    "state": 1,
                                                    "zipcode": 1,
                                                    "blast_id": 1,
                                                    "mls_number": 1,
                                                    "board": 1,
                                                    "property_type": 1,
                                                    "property_style": 1,
                                                    "lot_size": 1,
                                                    "number_bedrooms": 1,
                                                    "building_size": 1,
                                                    "number_stories": 1,
                                                    "number_bathrooms": 1,
                                                    "year_built": 1,
                                                    "garage": 1,
                                                    "garageSize": 1,
                                                    "price": 1,
                                                    "pricingInfo": 1,
                                                    "property_details": 1,
                                                    "isOpenHouse": 1,
                                                    "propertyImages": 1,
                                                    "linksToWebsites": 1,
                                                    "templates.email_subject": 1,
                                                    "templates.from_line": 1,
                                                    "templates.address": 1,
                                                    "templates.Property_id": 1,
                                                    "templates.headline": 1,
                                                    "templates.template_type": 1,
                                                    "templates.userId": 1,
                                                    "users.userName": 1,
                                                    "users.firstName": 1,
                                                    "users.lastName": 1,
                                                    "users.roles": 1,
                                                    "blasts": 1,
                                                }
                                            },
                                            {
                                                $match: {
                                                    blast_id: mongoose.Types.ObjectId(_propertyforms.blast_id.toString())
                                                }
                                            }
                                        ];
                                        _propertyBusiness.aggregate(propertyAggregate, function (error, result) {
                                            if (error) {
                                                res.send({ "error": error });
                                            }
                                            else {
                                                var returnObj = result.map(function (obj) {
                                                    return {
                                                        id: obj._id,
                                                        firstName: obj.users.firstName,
                                                        lastName: obj.users.lastName,
                                                        middleName: obj.users.middleName,
                                                        building_size: obj.building_size,
                                                        number_bathrooms: obj.number_bathrooms,
                                                        isOpenHouse: obj.isOpenHouse,
                                                        property_type: obj.property_type,
                                                        property_style: obj.property_style,
                                                        mls_number: obj.mls_number,
                                                        linksToWebsites: obj.linksToWebsites,
                                                        property_detail: obj.property_details,
                                                        pricingInfo: obj.pricingInfo,
                                                        board: obj.board,
                                                        zipcode: obj.zipcode,
                                                        city: obj.city,
                                                        display_method: obj.display_method,
                                                        street_address: obj.street_address,
                                                        number_bedrooms: obj.number_bedrooms,
                                                        year_built: obj.year_built,
                                                        number_stories: obj.number_stories,
                                                        lot_size: obj.lot_size,
                                                        templates: obj.templates,
                                                        price: obj.price,
                                                        garageSize: obj.garageSize,
                                                        blast_id: obj.blast_id,
                                                        agentData: obj.blasts,
                                                        propertyImages: obj.propertyImages
                                                    };
                                                });
                                                //console.log("returnObj=====",returnObj);
                                                return res.json(returnObj);
                                            }
                                        });
                                    });
                                }
                            }
                        });
                    });
                });
            }
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.savePropertyImages = function (data, id, res) {
        var _blastimageBusiness = new BlastImageBusiness();
        var _blastimage = data;
        var type = data.mimetype.split("/");
        var userid = id.toString();
        _blastimage.user_id = userid;
        _blastimage.url = data.filename;
        _blastimageBusiness.create(_blastimage, function (error, resultData) {
            if (error) {
                console.log("error===", error);
            }
            else {
                return res.json({ url: resultData.url, imageId: resultData._id });
            }
        });
    };
    UserController.prototype.deleteSavedBlast = function (req, res) {
        try {
            var _blastBusiness = new BlastBusiness();
            var _agentTemplateBusiness_1 = new AgentTemplateBusiness();
            var _propertyBusiness = new PropertyBusiness();
            var _id = req.params.id;
            _blastBusiness.findById(_id, function (error, result) {
                var _id = result._id.toString();
                var selected_template_id = result.selected_template_id;
                _blastBusiness.delete(_id, function (error, deleted) {
                    if (error) {
                        res.send({ "error": "error" });
                    }
                    else {
                        var _id_2 = selected_template_id;
                        _agentTemplateBusiness_1.findById(_id_2, function (error, result) {
                            var propertyid = result.Property_id.toString();
                            _agentTemplateBusiness_1.delete(_id_2, function (error, template) {
                                if (error) {
                                    res.send({ "error": "error" });
                                }
                                var _id = propertyid;
                                _propertyBusiness.findById(_id, function (error, result) {
                                    _propertyBusiness.delete(_id, function (error, template) {
                                        res.send({ "sucess": "sucess" });
                                    });
                                });
                            });
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveImages = function (req, res) {
        try {
            var _property = req.body;
            var _propertyBusiness = new PropertyBusiness();
            var array_1 = [];
            _property.property_ids.forEach(function (item) {
                var _id = item.id;
                _propertyBusiness.update(_id, _property, function (error, resultUpdate) {
                    if (error) {
                        res.send({ "error": "error in your request" });
                    }
                    else {
                        _propertyBusiness.findById(_id, function (error, result) {
                            if (error) {
                                res.send({ "error": "error in your request" });
                            }
                            else {
                                array_1.push(result);
                                res.send({ "success": "success", data: array_1 });
                            }
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.savePayment = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                var _payment = req.body;
                _payment.createdOn = new Date();
                _payment.user_id = userData._id;
                var _paymentBusiness = new PaymentBusiness();
                _payment.blast_id = req.params.blastId;
                _payment.amount = _payment.total;
                _payment.paymentID = _payment.paymentID;
                var blastId = req.params.blastId;
                _paymentBusiness.retrieve({ "blast_id": blastId }, function (error, result) {
                    if (result && result.length > 0) {
                        console.log("lastInvoiceId====", result.length);
                        var lastInvoiceId = +result.length + +1;
                        console.log("lastInvoiceId====", lastInvoiceId);
                        _payment.invoice_id = lastInvoiceId;
                    }
                    else {
                        var invoice_number = 1;
                        _payment.invoice_id = invoice_number;
                    }
                    _paymentBusiness.create(_payment, function (error, paymentresultData) {
                        if (error) {
                            console.log("error====", error);
                        }
                        else {
                            res.status(201).send({ "success": "Your payment successfully done." });
                        }
                    });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getSavedBlast = function (req, res) {
        try {
            var _blastform = req.body;
            var _blastBusiness = new BlastBusiness();
            var userId = req.params.agentId;
            var savedBlastAggregate = [
                {
                    $lookup: {
                        from: "templates",
                        localField: "user_id",
                        foreignField: "userId",
                        as: "templates"
                    }
                },
                {
                    $lookup: {
                        from: "payment",
                        localField: "user_id",
                        foreignField: "user_id",
                        as: "payment"
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        "user_id": 1,
                        "status": 1,
                        "selected_template_date": 1,
                        "scheduledDate": 1,
                        "templates.headline": 1,
                        "payment.amount": 1
                    }
                },
                {
                    $match: {
                        user_id: mongoose.Types.ObjectId(userId)
                    }
                }
            ];
            _blastBusiness.aggregate(savedBlastAggregate, function (error, result) {
                if (error) {
                    res.send({ "error": error });
                }
                else {
                    var returnObj = result.map(function (obj) {
                        return {
                            id: obj._id,
                            status: obj.status,
                            payment: obj.payment,
                            subject: obj.templates,
                            createdon: obj.selected_template_date,
                            scheduledDate: obj.scheduledDate
                        };
                    });
                    return res.json(returnObj);
                }
            });
        }
        catch (e) {
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getPayment = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                var _payment = req.body;
                var _paymentBusiness = new PaymentBusiness();
                var userId = req.params._id;
                _paymentBusiness.retrieve({ "user_id": userId }, function (error, result) {
                    if (error) {
                        console.log("error====", error);
                    }
                    else {
                        return res.json({ payment: result });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveBlastCalender = function (req, res) {
        try {
            var _blastBusiness = new BlastBusiness();
            var _id = req.params.blastId;
            _blastBusiness.findById(_id, function (error, result) {
                var _id = result._id.toString();
                var _blastform = req.body;
                _blastform.scheduledDate = _blastform.data;
                _blastBusiness.findOne({ "_id": _id }, function (error, dataBaseData) {
                    _blastBusiness.update(_id, _blastform, function (error, resultUpdate) {
                        if (error) {
                        }
                        else {
                            var _blastSettingsBusiness = new BlastSettingsBusiness();
                            _blastSettingsBusiness.retrieve("", function (error, result) {
                                if (error) {
                                    res.send({ "error": error });
                                }
                                else {
                                    console.log("get settings dataBaseData", dataBaseData);
                                    res.send({ "success": "success", data: _blastform.scheduledDate, dataBaseData: dataBaseData, blastsettingData: result });
                                }
                            });
                        }
                    });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getTemplateOrPropertydata = function (req, res) {
        try {
            var _property = req.body;
            var _propertyBusiness = new PropertyBusiness();
            var _blastform = req.body;
            //console.log("_blastform===",_blastform);
            var propertyAggregate = [
                {
                    $lookup: {
                        from: "users",
                        localField: "userId",
                        foreignField: "_id",
                        as: "users"
                    }
                },
                {
                    $unwind: "$users"
                },
                {
                    $lookup: {
                        from: "templates",
                        localField: "_id",
                        foreignField: "Property_id",
                        as: "templates"
                    }
                },
                {
                    $lookup: {
                        from: "blasts",
                        localField: "blast_id",
                        foreignField: "_id",
                        as: "blasts"
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        "userId": 1,
                        "display_method": 1,
                        "street_address": 1,
                        "city": 1,
                        "state": 1,
                        "zipcode": 1,
                        "blast_id": 1,
                        "mls_number": 1,
                        "board": 1,
                        "property_type": 1,
                        "property_style": 1,
                        "lot_size": 1,
                        "number_bedrooms": 1,
                        "building_size": 1,
                        "number_stories": 1,
                        "number_bathrooms": 1,
                        "year_built": 1,
                        "garage": 1,
                        "garageSize": 1,
                        "price": 1,
                        "pricingInfo": 1,
                        "property_details": 1,
                        "isOpenHouse": 1,
                        "propertyImages": 1,
                        "linksToWebsites": 1,
                        "templates.email_subject": 1,
                        "templates.from_line": 1,
                        "templates.address": 1,
                        "templates.Property_id": 1,
                        "templates.headline": 1,
                        "templates.template_type": 1,
                        "templates.userId": 1,
                        "users.userName": 1,
                        "users.firstName": 1,
                        "users.lastName": 1,
                        "users.roles": 1,
                        "blasts": 1,
                    }
                },
                {
                    $match: {
                        blast_id: mongoose.Types.ObjectId(_blastform.blast_id)
                    }
                }
            ];
            _propertyBusiness.aggregate(propertyAggregate, function (error, result) {
                if (error) {
                    res.send({ "error": error });
                }
                else {
                    var returnObj = result.map(function (obj) {
                        return {
                            id: obj._id,
                            firstName: obj.users.firstName,
                            lastName: obj.users.lastName,
                            middleName: obj.users.middleName,
                            building_size: obj.building_size,
                            number_bathrooms: obj.number_bathrooms,
                            isOpenHouse: obj.isOpenHouse,
                            property_type: obj.property_type,
                            property_style: obj.property_style,
                            mls_number: obj.mls_number,
                            linksToWebsites: obj.linksToWebsites,
                            property_detail: obj.property_details,
                            pricingInfo: obj.pricingInfo,
                            board: obj.board,
                            zipcode: obj.zipcode,
                            city: obj.city,
                            display_method: obj.display_method,
                            street_address: obj.street_address,
                            number_bedrooms: obj.number_bedrooms,
                            year_built: obj.year_built,
                            number_stories: obj.number_stories,
                            lot_size: obj.lot_size,
                            templates: obj.templates,
                            price: obj.price,
                            garageSize: obj.garageSize,
                            blast_id: obj.blast_id,
                            agentData: obj.blasts,
                            propertyImages: obj.propertyImages
                        };
                    });
                    return res.json(returnObj);
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return UserController;
}());
module.exports = UserController;
//# sourceMappingURL=UserController.js.map