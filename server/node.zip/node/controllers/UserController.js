"use strict";
/**
 * api call lands here from routing
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var UserBusiness = require("./../app/business/UserBusiness");
var AdminUserBusiness = require("./../app/business/AdminUserBusiness");
var ContactformBusiness = require("./../app/business/ContactformBusiness");
var BlastBusiness = require("./../app/business/BlastBusiness");
var PropertyBusiness = require("./../app/business/PropertyBusiness");
var PaymentBusiness = require("./../app/business/PaymentBusiness");
var AgentTemplateBusiness = require("./../app/business/AgentTemplateBusiness");
var Common = require("./../config/constants/common");
var AgentBusiness = require("./../app/business/AgentBusiness");
var BlastImageBusiness = require("./../app/business/BlastImageBusiness");
var BlastSettingsBusiness = require("./../app/business/BlastSettingsBusiness");
var moment = require('moment');
var mammoth = require("mammoth");
var fs = require('fs');
var _ = require('underscore');
var mongoose = require('mongoose');
var async = require('async');
var base64Img = require('base64-img');
var stripe = require("stripe")(Common.STRIPESECRETKEY);
var UserController = (function () {
    function UserController() {
    }
    //being called by client getEmailExists
    UserController.prototype.getEmailExists = function (req, res) {
        try {
            var query = req.params.query;
            var _userBusiness = new UserBusiness();
            _userBusiness.count({ 'email': { $regex: "^" + (query.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')) + "$", $options: "i" } }, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": "error" });
                }
                else {
                    res.send(JSON.stringify(result));
                }
                ;
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.register = function (req, res) {
        try {
            var user = req.body.user;
            //console.log("user====",user);
            user.createdOn = new Date();
            user.phone = req.body.user.phoneno;
            user.password = req.body.user.password;
            user.firstName = req.body.user.firstName.toLowerCase();
            user.roles = 'agents';
            user.lastName = req.body.user.lastName.toLowerCase();
            user.paidOn = false;
            user.isDeleted = false;
            var userBusiness = new UserBusiness();
            var token = userBusiness.createToken(user);
            userBusiness.create(user, function (error, userdata) {
                if (error) {
                    console.log("error==sss==", error);
                    res.send({
                        "error": error
                    });
                }
                else {
                    var signupemailtemplatetouser = Common.SIGNUP_EMAIL_TEMPLATE_TO_REGISTERED_USER;
                    var emailtemplate = signupemailtemplatetouser.replace(/#email#/g, userdata.email).replace(/#password#/g, userdata.password);
                    Common.sendMail(userdata.email, Common.ADMIN_EMAIL, 'Welcome to ListingReach!', null, emailtemplate, function (error, response) {
                        if (error) {
                            res.send("error");
                        }
                        else {
                            res.send({ "success": "success" });
                        }
                    });
                    res.send({ "success": "success" });
                }
            });
        }
        catch (e) {
            res.send({
                "error": "error in your request"
            });
        }
    };
    UserController.prototype.authenticate = function (req, res) {
        try {
            var _user = req.body;
            //set the createdon to now
            var _userBusiness = new UserBusiness();
            _userBusiness.findOne({ email: _user.email }, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    if (result && result.password && result.password == _user.password) {
                        if (result.isDeleted && result.isDeleted === true) {
                            return res.status(401).send({ "error": "Your account is no longer available. Please contact admin." });
                        }
                        else {
                            if (result.status == 'unverified') {
                                return res.status(401).send({ "error": "Your account is not active. Please contact admin." });
                            }
                            else {
                                var token = _userBusiness.createToken(result);
                                var _updateData = req.body;
                                _updateData.lastLogin = new Date();
                                _updateData.token = token;
                                var _id = result._id.toString();
                                var _userBusinessUpdate = new UserBusiness();
                                _userBusinessUpdate.update(_id, _updateData, function (error, resultUpdate) {
                                    if (error)
                                        res.send({ "error": "error", "message": "Authentication error" }); //res.status(401).send({"error": "Authentication error"});
                                    else {
                                        res.send({
                                            userId: result._id,
                                            email: result.email,
                                            firstName: result.firstName,
                                            lastName: result.lastName,
                                            phone: result.phone,
                                            token: token,
                                            roles: result.roles
                                        });
                                    }
                                });
                            }
                        }
                    }
                    else {
                        return res.status(401).send({ "error": "The username or password don't match" });
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.create = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                var _user = req.body;
                _user.createdOn = new Date();
                var _userBusiness = new UserBusiness();
                _userBusiness.create(_user, function (error, result) {
                    if (error) {
                        res.send({ "error": error });
                    }
                    else
                        res.send({ "success": "success" });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.updateStatus = function (req, res) {
        try {
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.updateUser = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (UserData) {
                var _user = req.body.user;
                var _id = _user.id.toString();
                _userBusiness.update(mongoose.Types.ObjectId(_id), _user, function (error, userdata) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": error });
                    }
                    else {
                        var _agentBusiness = new AgentBusiness();
                        async.parallel({
                            agentData: function (callback) {
                                _agentBusiness.findOne({ 'userId': _id }, function (error, agentdata) {
                                    if (error) {
                                    }
                                    else {
                                        callback(null, agentdata);
                                    }
                                });
                            },
                            userData: function (callback) {
                                _userBusiness.retrieve({ _id: _id }, function (error, result) {
                                    var returnObj = result.map(function (obj) {
                                        return {
                                            id: obj._id,
                                            userName: obj.userName,
                                            firstName: obj.firstName,
                                            lastName: obj.lastName,
                                            status: obj.status,
                                            email: obj.email,
                                            companyName: obj.companyName,
                                            phone: obj.phone,
                                            city: obj.city,
                                            zipcode: obj.zipcode,
                                            roles: obj.roles
                                        };
                                    });
                                    callback(null, returnObj);
                                });
                            }
                        }, function (err, results) {
                            if (err) {
                                res.send({ "error": "error" });
                            }
                            res.json({ "status": "success", "data": results });
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.updateprofilepic = function (data, id, res, flag) {
        var _this = this;
        var _agentBusiness = new AgentBusiness();
        var _agent = data;
        _agent.createdOn = new Date();
        var type = data.mimetype.split("/");
        var userid = id.toString();
        var _id = userid;
        _agent.userId = userid;
        if (flag == 'logo') {
            _agent.logo_url = data.filename;
        }
        else {
            _agent.image_url = data.filename;
        }
        _agentBusiness.findOne({ 'userId': userid }, function (error, agentresult) {
            if (agentresult != null) {
                var _id = agentresult._id.toString();
                _agentBusiness.update(_id, _agent, function (error, resultUpdate) {
                    if (error) {
                    }
                    else {
                        _agentBusiness.findById(_id, function (agentError, result) { return __awaiter(_this, void 0, void 0, function () {
                            return __generator(this, function (_a) {
                                return [2 /*return*/, res.json({ profileimg: result })];
                            });
                        }); });
                    }
                });
            }
            else {
                _agentBusiness.create(_agent, function (error, agentresultData) {
                    if (error) {
                    }
                    else {
                        return res.json({ profileimg: agentresultData });
                    }
                });
            }
        });
    };
    UserController.prototype.delete = function (req, res) {
        try {
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.retrieve = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                _userBusiness.retrieve(req.body, function (error, result) {
                    if (error)
                        res.send({ "error": "error" });
                    else
                        res.send(result);
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.findById = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            var _agentBusiness = new AgentBusiness();
            var _balstimageBusiness = new BlastImageBusiness();
            _userBusiness.verifyToken(req, res, function (userdata) {
                async.parallel({
                    agentData: function (callback) {
                        _agentBusiness.retrieve({ 'userId': userdata.id }, function (error, agentdata) {
                            if (error) {
                            }
                            else {
                                var returnObjagent = agentdata.map(function (obj) {
                                    return {
                                        id: obj._id,
                                        name: obj.name,
                                        email: obj.email,
                                        designation: obj.designation,
                                        website_url: obj.website_url,
                                        phone_number: obj.phone_number,
                                        company_details: obj.company_details,
                                        other_information: obj.other_information,
                                        image_url: obj.image_url,
                                        logo_url: obj.logo_url
                                    };
                                });
                                callback(null, returnObjagent);
                            }
                        });
                    },
                    imageData: function (callback) {
                        _balstimageBusiness.retrieve({ 'user_id': userdata.id }, function (error, imagedata) {
                            if (error) {
                            }
                            else {
                                var returnObjimage = imagedata.map(function (obj) {
                                    return {
                                        id: obj._id,
                                        url: obj.url,
                                    };
                                });
                                callback(null, returnObjimage);
                            }
                        });
                    },
                    userData: function (callback) {
                        _userBusiness.retrieve({ _id: userdata.id }, function (error, result) {
                            var returnObj = result.map(function (obj) {
                                return {
                                    id: obj._id,
                                    userName: obj.userName,
                                    firstName: obj.firstName,
                                    lastName: obj.lastName,
                                    status: obj.status,
                                    email: obj.email,
                                    companyName: obj.companyName,
                                    phone: obj.phone,
                                    city: obj.city,
                                    zipcode: obj.zipcode,
                                    roles: obj.roles,
                                    state: obj.state
                                };
                            });
                            callback(null, returnObj);
                        });
                    }
                }, function (err, results) {
                    if (err) {
                        res.send({ "error": "error" });
                    }
                    res.json({ "status": "success", "data": results });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.findByToken = function (req, res) {
        var _userBusiness = new UserBusiness();
        _userBusiness.verifyToken(req, res, function (UserData) {
            res.send(UserData);
        });
    };
    UserController.prototype.contactForm = function (req, res) {
        try {
            var _contactform = req.body;
            var _contactformBusiness = new ContactformBusiness();
            _contactform.fullname = req.body.fullname;
            _contactform.email = req.body.email;
            _contactform.phone = req.body.phone;
            _contactform.message = req.body.message;
            _contactform.createdOn = new Date();
            _contactformBusiness.create(_contactform, function (error, result) {
                if (error) {
                    res.send({ "error=========": error });
                }
                else {
                    var contactFormemail = Common.CONTACT_FORM;
                    var emailtemplate = contactFormemail.replace(/#fullname#/g, _contactform.fullname).replace(/#email#/g, _contactform.email).replace(/#phone#/g, _contactform.phone).replace(/#message#/g, _contactform.message).replace(/#date#/g, _contactform.createdOn);
                    Common.sendMail('salvep@salvesoft.com', _contactform.email, 'Contact Form', null, emailtemplate, function (error, response) {
                        if (error) {
                            res.end("error");
                        }
                    });
                    res.status(201).send({ "success": "done" });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.emailPreviewTemplate = function (req, res) {
        var _this = this;
        try {
            var _IagentTemplateModel_1 = req.body;
            var _agentTemplateBusiness = new AgentTemplateBusiness();
            var blastBusiness_1 = new BlastBusiness();
            var blastid_1 = _IagentTemplateModel_1.blast_id;
            blastBusiness_1.findById(blastid_1, function (blastError, blast) { return __awaiter(_this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, blastBusiness_1.getEmailHTML(blastid_1).then(function (HTML) {
                                if (HTML == null) {
                                    res.send("Error generating email.");
                                    return;
                                }
                                if (_IagentTemplateModel_1.email) {
                                    Common.sendMail(_IagentTemplateModel_1.email, 'support@ListingReach.com', 'Property Email', null, HTML, function (error, response) {
                                        if (error) {
                                            console.log(error);
                                            res.end("error");
                                        }
                                    });
                                    res.send({ "success": "Done" });
                                }
                            })];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            }); });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.forgetUserPassword = function (req, res) {
        try {
            var _user = req.body;
            var _userBusiness = new UserBusiness();
            _userBusiness.findOne({ email: _user.email }, function (error, result) {
                if (error) {
                    res.send({ "error": "error" });
                }
                else {
                    if (result && result.email == _user.email) {
                        if (result.status == 'unverified') {
                            return res.status(401).send({ "error": "Your account is not verified. Please contact admin." });
                        }
                        else {
                            var token = _userBusiness.createToken(result);
                            var _updateData = req.body;
                            _updateData.lastLogin = new Date();
                            _updateData.token = token;
                            var _id = result._id.toString();
                            var _userBusinessUpdate = new UserBusiness();
                            // Generate new password ...
                            var autoGeneratedPassword = Math.random().toString(36).slice(-8);
                            _user.password = 'P' + autoGeneratedPassword;
                            _userBusinessUpdate.update(_id, _updateData, function (error, resultUpdate) {
                                if (error)
                                    res.send({ "error": "error", "message": "Authentication error" }); //res.status(401).send({"error": "Authentication error"});
                                else {
                                    var _userBusiness = new UserBusiness();
                                    _userBusiness.findById(_id, function (error, resultuser) {
                                        if (error)
                                            res.send({ "error": "error", "message": "Authentication error" });
                                        else {
                                            var emailresetpassword = Common.EMAIL_TEMPLATE_RESET_USER_PASSWORD;
                                            var emailtemplate = emailresetpassword.replace(/#password#/g, _user.password);
                                            Common.sendMail(result.email, 'support@ListingReach.com', 'Forgot Password', null, emailtemplate, function (error, response) {
                                                if (error) {
                                                    console.log(error);
                                                    res.end("error");
                                                }
                                            });
                                            res.status(201).send({ "success": "done" });
                                        }
                                    });
                                }
                            });
                        }
                    }
                    else {
                        return res.status(401).send({ "error": "You have entered invalid email." });
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.UpdateUserPassword = function (req, res) {
        try {
            var _user = req.body;
            var _userBusiness = new UserBusiness();
            var _idc = req.body.user;
            _user.password = req.body.newpassword;
            _userBusiness.findOne({ _id: _idc, password: req.body.currentpassword }, function (error, result) {
                if (error) {
                    res.send({ "error": "Please enter current vaild password." });
                }
                else if (result == null) {
                    res.send({ "error": "Please enter current vaild password." });
                }
                else {
                    _user.password = req.body.newpassword;
                    _userBusiness.update(_idc, _user, function (error, resultUpdate) {
                        if (error)
                            res.send({ "error": "error", "message": "Your password is not updated." });
                        else {
                            res.status(201).send({ "success": "Your password is successfully updated." });
                        }
                    });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.selectDatabase = function (req, res) {
        try {
            var _blastform = req.body;
            var _id = req.body.blast_id;
            var _blastBusiness = new BlastBusiness();
            console.log("_blastform=====", _blastform);
            /*					if(property.isOpenHouse){
                                    var opneHouseData=[];
                                    let data = property.isOpenHouse.openHouseData;
                                                data.forEach(function(house:any) {
                                                if(house){
                                                    opneHouseData.push({openHouseData:house.openHouseData});
                                                }
                                            });
                                   _propertyform.isOpenHouse=opneHouseData;
                            }*/
            _blastBusiness.update(_id, _blastform, function (error, resultUpdate) {
                if (error) {
                    console.log("save asscoiations error :", error);
                    res.send({ "error": error });
                }
                else {
                    res.send({ "success": "success" });
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.forgetSAdminPassword = function (req, res) {
        try {
            var _user = req.body;
            var _adminUserBusiness = new AdminUserBusiness();
            var _userBusiness = new UserBusiness();
            _adminUserBusiness.findOne({ email: _user.email }, function (error, result) {
                if (error)
                    res.send({ "error": "error" });
                else {
                    if (result && result.email == _user.email) {
                        if (!result.isActive) {
                            return res.status(401).send({ "error": "Your account is not active. Please contact admin." });
                        }
                        else {
                            var token = _userBusiness.createToken(result);
                            var _updateAdminData = req.body;
                            _updateAdminData.lastLogin = new Date();
                            _updateAdminData.token = token;
                            var _id = result._id.toString();
                            var _adminUserBusiness = new AdminUserBusiness();
                            // Generate new password ...
                            var autoGeneratedPassword = Math.random().toString(36).slice(-8);
                            _user.password = 'P' + autoGeneratedPassword;
                            _adminUserBusiness.update(_id, _updateAdminData, function (error, resultUpdate) {
                                if (error)
                                    res.send({ "error": "error", "message": "Authentication error" }); //res.status(401).send({"error": "Authentication error"});
                                else {
                                    var companyId = result._id;
                                    _adminUserBusiness.retrieve(companyId, function (error, resultCompany) {
                                        if (error)
                                            res.send({ "error": "error", "message": "Authentication error" });
                                        else {
                                            var emailresetpassword = Common.EMAIL_TEMPLATE_RESET_ADMIN_PASSWORD;
                                            var emailtemplate = emailresetpassword.replace(/#password#/g, _user.password);
                                            Common.sendMail(result.email, 'support@inteleagent.com', 'Forgot Password', null, emailtemplate, function (error, response) {
                                                if (error) {
                                                    console.log(error);
                                                    res.end("error");
                                                }
                                            });
                                            res.status(201).send({ "success": "done" });
                                        }
                                    });
                                }
                            });
                        }
                    }
                    else {
                        return res.status(401).send({ "error": "Invalid email." });
                    }
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.verifytoken = function (req, res) {
        var _userBusiness = new UserBusiness();
        _userBusiness.verifyToken(req, res, function (userData) {
            res.status(201).send({
                token: "valid"
            });
        });
    };
    //tbd split the incoming query to be {a:b} instead of a=b
    UserController.prototype.count = function (req, res) {
        try {
            var query = req.params.query;
            var _userBusiness = new UserBusiness();
            _userBusiness.count(query, function (error, result) {
                if (error) {
                    console.log(error);
                    res.send({ "error": "error" });
                }
                else {
                    res.send(result);
                }
                ;
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getReferences = function (req, res) {
        try {
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveBlast = function (req, res) {
        try {
            var _blastform = req.body;
            var blastId = req.body.blastId;
            var _blastBusiness = new BlastBusiness();
            _blastform.status = 'Draft';
            _blastform.selected_template_date = new Date();
            if (!blastId) {
                _blastBusiness.create(_blastform, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": error });
                    }
                    else
                        res.send({ "success": "success", data: result });
                });
            }
            else {
                _blastBusiness.update(blastId, _blastform, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": error });
                    }
                    else
                        res.send({ "success": "success", data: result });
                });
            }
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveDesignTemplate = function (req, res) {
        try {
            var _IagentTemplateModel = req.body;
            var _agentTemplateBusiness = new AgentTemplateBusiness();
            var _blastform_1 = req.body;
            var templateId = req.body.templateId;
            var _blastBusiness_1 = new BlastBusiness();
            _blastform_1.selected_template_date = new Date();
            if (!templateId) {
                _agentTemplateBusiness.create(_IagentTemplateModel, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": error });
                    }
                    else {
                        if (result && result._id) {
                            _blastform_1.selected_template_id = result._id;
                            _blastform_1.status = 'Draft';
                            _blastBusiness_1.findOne({ _id: req.body.blastId }, function (error, user) {
                                var _id = user._id.toString();
                                _blastBusiness_1.update(_id, _blastform_1, function (error, resultUpdate) {
                                    if (error) {
                                        console.log(error);
                                        res.send(error);
                                    }
                                    else {
                                        return res.json({ "sucess": "sucess", "data": result });
                                    }
                                });
                            });
                        }
                    }
                });
            }
            else {
                _agentTemplateBusiness.update(templateId, _IagentTemplateModel, function (error, resultUpdate) {
                    if (error) {
                        console.log(error);
                        res.send(error);
                    }
                    else {
                        return res.json({ "sucess": "sucess", "data": resultUpdate });
                    }
                });
            }
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveAgents = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                var _agent = req.body;
                console.log("_agent====", _agent);
                _agent.createdOn = new Date();
                _agent.user_id = userData._id;
                var _agentBusiness = new AgentBusiness();
                _agentBusiness.findOne({ 'userId': userData._id }, function (error, agentresult) {
                    if (agentresult) {
                        var _id = agentresult._id.toString();
                        _agentBusiness.update(_id, _agent, function (error, resultUpdate) {
                            if (error) {
                            }
                            else {
                                res.status(201).send({ "success": "Your agent info successfully updated." });
                                return res.json({ data: resultUpdate });
                            }
                        });
                    }
                    else {
                        _agentBusiness.create(_agent, function (error, agentresultData) {
                            if (error) {
                                console.log("error====", error);
                            }
                            else {
                                res.status(201).send({ "success": "Your agent info successfully updated." });
                            }
                        });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveProperty = function (req, res) {
        try {
            //	console.log("Properties Body : ", req.body)
            var _propertyforms = req.body;
            var _propertyBusiness = new PropertyBusiness();
            var _templateform = void 0;
            if (_propertyforms && _propertyforms.properties && _propertyforms.properties.length) {
                var _templateBusiness = new AgentTemplateBusiness();
                var _blastform = req.body;
                var _blastBusiness = new BlastBusiness();
                _propertyforms.properties.forEach(function (prop) {
                    if (prop._id) {
                        _propertyBusiness.update(prop._id.toString(), prop, function (error, result) {
                            if (error) {
                                console.log("Property update error :", error);
                                res.send({ "error": error });
                                return;
                            }
                        });
                    }
                    else {
                        prop.blast_id = req.body.blastId;
                        _propertyBusiness.create(prop, function (error, result) {
                            if (error) {
                                console.log("Property create error :", error);
                                res.send({ "error": error });
                                return;
                            }
                        });
                    }
                });
                var _template = req.body.template;
                console.log("Template ", _template);
                _templateBusiness.update(_template._id.toString(), _template, function (error, resultUpdate) {
                    if (error) {
                        console.log("template update error ", error);
                        res.send({ "error": error });
                    }
                });
                var agentData = req.body.agentData;
                var blast = {
                    agentData: agentData
                };
                var blastId = req.body.blastId;
                if (agentData) {
                    _blastBusiness.update(blastId, blast, function (error, blastUpadte) {
                        if (error) {
                            res.send({ "blast update error": error });
                        }
                    });
                }
                res.send({ template: _template });
            }
        }
        catch (e) {
            console.log(e);
            res.send({ "error": e });
        }
    };
    UserController.prototype.savePropertyImages = function (data, id, res) {
        var _blastimageBusiness = new BlastImageBusiness();
        var _blastimage = data;
        var type = data.mimetype.split("/");
        var userid = id.toString();
        _blastimage.user_id = userid;
        _blastimage.url = data.filename;
        _blastimageBusiness.create(_blastimage, function (error, resultData) {
            if (error) {
                console.log("error===", error);
            }
            else {
                return res.json({ url: resultData.url, imageId: resultData._id });
            }
        });
    };
    UserController.prototype.deleteSavedBlast = function (req, res) {
        try {
            var _blastBusiness = new BlastBusiness();
            var _agentTemplateBusiness_1 = new AgentTemplateBusiness();
            var _propertyBusiness = new PropertyBusiness();
            var _id = req.params.id;
            _blastBusiness.findById(_id, function (error, result) {
                var _id = result._id.toString();
                var selected_template_id = result.selected_template_id;
                _blastBusiness.delete(_id, function (error, deleted) {
                    if (error) {
                        res.send({ "error": "error" });
                    }
                    else {
                        var _id_1 = selected_template_id;
                        _agentTemplateBusiness_1.findById(_id_1, function (error, result) {
                            var propertyid = result.Property_id.toString();
                            _agentTemplateBusiness_1.delete(_id_1, function (error, template) {
                                if (error) {
                                    res.send({ "error": "error" });
                                }
                                var _id = propertyid;
                                _propertyBusiness.findById(_id, function (error, result) {
                                    _propertyBusiness.delete(_id, function (error, template) {
                                        res.send({ "sucess": "sucess" });
                                    });
                                });
                            });
                        });
                        res.send({ message: "success" });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getPreviewhtml = function (req, res) {
        var _this = this;
        try {
            var blastid = req.params.id;
            //console.log("blastid====",blastid);
            var blastBusiness_2 = new BlastBusiness();
            blastBusiness_2.findById(blastid, function (blastError, blast) { return __awaiter(_this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!blastError) return [3 /*break*/, 1];
                            res.send(blastError);
                            return [3 /*break*/, 3];
                        case 1: 
                        //console.log("blast====",blast.id);
                        return [4 /*yield*/, blastBusiness_2.getEmailHTML(blast.id).then(function (HTML) {
                                if (HTML == null) {
                                    res.send("Error generating email.");
                                }
                                else {
                                    //console.log("HTML======",HTML);
                                    res.send({ "html": HTML });
                                }
                            })];
                        case 2:
                            //console.log("blast====",blast.id);
                            _a.sent();
                            _a.label = 3;
                        case 3: return [2 /*return*/];
                    }
                });
            }); });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveImages = function (req, res) {
        try {
            var _propertyBusiness = new PropertyBusiness();
            req.body.properties.forEach(function (property) {
                var _id = property._id.toString();
                _propertyBusiness.update(_id, property, function (error, resultUpdate) {
                    if (error) {
                        res.send({ "error": "error in your request" });
                    }
                });
            });
            res.send({ message: "success" });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.savePayment = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            _userBusiness.verifyToken(req, res, function (userData) {
                var _payment = req.body;
                _payment.createdOn = new Date();
                _payment.user_id = userData._id;
                var _paymentBusiness = new PaymentBusiness();
                _payment.blast_id = req.params.blastId;
                _payment.amount = _payment.total;
                _payment.paymentID = _payment.paymentID;
                var blastId = req.params.blastId;
                _paymentBusiness.retrieve({ "user_id": userData._id }, function (error, result) {
                    if (result && result.length > 0) {
                        var lastInvoiceId = +result.length + +1;
                        _payment.invoice_id = lastInvoiceId;
                    }
                    else {
                        var invoice_number = 1;
                        _payment.invoice_id = invoice_number;
                    }
                    _paymentBusiness.create(_payment, function (error, paymentresultData) {
                        if (error) {
                            console.log("error====", error);
                        }
                        else {
                            res.status(201).send({ "success": "Your payment successfully done." });
                        }
                    });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getBlast = function (req, res) {
        try {
            var blastId_1 = req.params.id;
            //	console.log("id: ", req.params)
            var blastBusiness = new BlastBusiness();
            blastBusiness.findById(blastId_1, function (error, blast) {
                if (error) {
                    console.log("error in getting blast :", error);
                    res.send(error);
                }
                else {
                    var _templateBusiness = new AgentTemplateBusiness();
                    console.log("ddddd", blastId_1.selected_template_id);
                    _templateBusiness.findById(blast.selected_template_id, function (templateError, template) {
                        if (templateError) {
                            console.log("error in getting template :", templateError);
                            res.send(error);
                        }
                        else {
                            console.log("Template ,", template);
                            var _propertyBusiness = new PropertyBusiness();
                            _propertyBusiness.retrieve({ blast_id: blast.id }, function (propertiesError, properties) {
                                if (propertiesError) {
                                    console.log("error in getting properties :", propertiesError);
                                    res.send(error);
                                }
                                else {
                                    res.send({ blast: blast, template: template, properties: properties });
                                }
                            });
                        }
                    });
                }
            });
        }
        catch (e) {
            console.log("Exception in getBlast", e);
            res.send(e);
        }
    };
    UserController.prototype.getSavedBlast = function (req, res) {
        try {
            var _blastBusiness = new BlastBusiness();
            var userId = req.params.agentId;
            var savedBlastAggregate = [
                {
                    $lookup: {
                        from: "templates",
                        localField: "selected_template_id",
                        foreignField: "_id",
                        as: "templates"
                    }
                },
                { $unwind: { path: "$templates" } },
                {
                    $lookup: {
                        from: "payments",
                        localField: "_id",
                        foreignField: "blast_id",
                        as: "payments"
                    }
                },
                { $unwind: { path: "$payments", preserveNullAndEmptyArrays: true } },
                {
                    $project: {
                        "_id": 1,
                        "user_id": 1,
                        "status": 1,
                        "selected_template_date": 1,
                        "selected_template_id": 1,
                        "scheduledDate": 1,
                        "templates.headline": 1,
                        "templates.template_type": 1,
                        "templates.email_subject": 1,
                        "payment.amount": 1
                    }
                },
                {
                    $match: {
                        user_id: mongoose.Types.ObjectId(userId)
                    }
                }
            ];
            _blastBusiness.aggregate(savedBlastAggregate, function (error, result) {
                if (error) {
                    res.send({ "error": error });
                }
                else {
                    var returnObj = result.map(function (obj) {
                        return {
                            id: obj._id,
                            status: obj.status,
                            payment: obj.payments && obj.payments.amount,
                            subject: obj.templates.email_subject,
                            createdon: obj.selected_template_date,
                            scheduledDate: obj.scheduledDate,
                            templateType: obj.templates.template_type,
                            templateId: obj.selected_template_id
                        };
                    });
                    return res.json(returnObj);
                }
            });
        }
        catch (e) {
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getPayment = function (req, res) {
        try {
            var _userBusiness = new UserBusiness();
            var userId = req.params._id;
            console.log("userId===", userId);
            _userBusiness.verifyToken(req, res, function (userData) {
                var paymentBusiness = new PaymentBusiness();
                var query = [
                    {
                        $lookup: {
                            from: "blasts",
                            localField: "blast_id",
                            foreignField: "_id",
                            as: "blast"
                        }
                    },
                    {
                        $project: {
                            _id: 1,
                            paymentID: 1,
                            createdOn: 1,
                            amount: 1,
                            user_id: 1,
                            invoice_id: 1,
                            "blast.blast_type": 1,
                            "blast.status": 1
                        }
                    },
                    {
                        $match: {
                            user_id: mongoose.Types.ObjectId(userId)
                        }
                    }
                ];
                paymentBusiness.aggregate(query, function (error, result) {
                    if (error) {
                        console.log(error);
                        res.send({ "error": error });
                    }
                    else {
                        console.log(result);
                        //res.send(result);
                        return res.json({ payment: result });
                    }
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.saveBlastCalender = function (req, res) {
        try {
            var _blastBusiness = new BlastBusiness();
            var _id = req.params.blastId;
            _blastBusiness.findById(_id, function (error, result) {
                var _id = result._id.toString();
                var _blastform = req.body;
                _blastform.scheduledDate = _blastform.data;
                _blastBusiness.findOne({ "_id": _id }, function (error, dataBaseData) {
                    _blastBusiness.update(_id, _blastform, function (error, resultUpdate) {
                        if (error) {
                        }
                        else {
                            var _blastSettingsBusiness = new BlastSettingsBusiness();
                            _blastSettingsBusiness.retrieve("", function (error, result) {
                                if (error) {
                                    res.send({ "error": error });
                                }
                                else {
                                    console.log("get settings dataBaseData", dataBaseData);
                                    res.send({ "success": "success", data: _blastform.scheduledDate, dataBaseData: dataBaseData, blastsettingData: result });
                                }
                            });
                        }
                    });
                });
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    UserController.prototype.getTemplateOrPropertydata = function (req, res) {
        try {
            var _propertyBusiness = new PropertyBusiness();
            var propertyAggregate = [
                {
                    $lookup: {
                        from: "users",
                        localField: "userId",
                        foreignField: "_id",
                        as: "users"
                    }
                },
                {
                    $unwind: "$users"
                },
                {
                    $lookup: {
                        from: "templates",
                        localField: "_id",
                        foreignField: "Property_id",
                        as: "templates"
                    }
                },
                {
                    $lookup: {
                        from: "blasts",
                        localField: "blast_id",
                        foreignField: "_id",
                        as: "blasts"
                    }
                },
                {
                    $project: {
                        "_id": 1,
                        "userId": 1,
                        "display_method": 1,
                        "street_address": 1,
                        "city": 1,
                        "state": 1,
                        "zipcode": 1,
                        "blast_id": 1,
                        "mls_number": 1,
                        "board": 1,
                        "property_type": 1,
                        "property_style": 1,
                        "lot_size": 1,
                        "number_bedrooms": 1,
                        "building_size": 1,
                        "number_stories": 1,
                        "number_bathrooms": 1,
                        "year_built": 1,
                        "garage": 1,
                        "garageSize": 1,
                        "price": 1,
                        "pricingInfo": 1,
                        "property_details": 1,
                        "isOpenHouse": 1,
                        "propertyImages": 1,
                        "linksToWebsites": 1,
                        "templates.email_subject": 1,
                        "templates.from_line": 1,
                        "templates.address": 1,
                        "templates.Property_id": 1,
                        "templates.headline": 1,
                        "templates.template_type": 1,
                        "templates.userId": 1,
                        "users.userName": 1,
                        "users.firstName": 1,
                        "users.lastName": 1,
                        "users.roles": 1,
                        "blasts": 1,
                    }
                },
                {
                    $match: {
                        blast_id: mongoose.Types.ObjectId(req.body.blast_id)
                    }
                }
            ];
            _propertyBusiness.aggregate(propertyAggregate, function (error, result) {
                if (error) {
                    res.send({ "error": error });
                }
                else {
                    var returnObj = result.map(function (obj) {
                        return {
                            id: obj._id,
                            firstName: obj.users.firstName,
                            lastName: obj.users.lastName,
                            middleName: obj.users.middleName,
                            building_size: obj.building_size,
                            number_bathrooms: obj.number_bathrooms,
                            isOpenHouse: obj.isOpenHouse,
                            property_type: obj.property_type,
                            property_style: obj.property_style,
                            mls_number: obj.mls_number,
                            linksToWebsites: obj.linksToWebsites,
                            property_detail: obj.property_details,
                            pricingInfo: obj.pricingInfo,
                            board: obj.board,
                            zipcode: obj.zipcode,
                            city: obj.city,
                            display_method: obj.display_method,
                            street_address: obj.street_address,
                            number_bedrooms: obj.number_bedrooms,
                            year_built: obj.year_built,
                            number_stories: obj.number_stories,
                            lot_size: obj.lot_size,
                            templates: obj.templates,
                            price: obj.price,
                            garageSize: obj.garageSize,
                            blast_id: obj.blast_id,
                            agentData: obj.blasts,
                            propertyImages: obj.propertyImages
                        };
                    });
                    return res.json(returnObj);
                }
            });
        }
        catch (e) {
            console.log(e);
            res.send({ "error": "error in your request" });
        }
    };
    return UserController;
}());
module.exports = UserController;
//# sourceMappingURL=UserController.js.map