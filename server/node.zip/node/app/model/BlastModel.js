"use strict";
var BlastModel = (function () {
    function BlastModel(BlastModel) {
        this._blastModel = BlastModel;
    }
    Object.defineProperty(BlastModel.prototype, "_id", {
        get: function () {
            return this._blastModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastModel.prototype, "user_id", {
        get: function () {
            return this._blastModel.user_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastModel.prototype, "blast_type", {
        get: function () {
            return this._blastModel.blast_type;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastModel.prototype, "selected_template_id", {
        get: function () {
            return this._blastModel.selected_template_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastModel.prototype, "agentData", {
        get: function () {
            return this._blastModel.agentData;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastModel.prototype, "associations", {
        get: function () {
            return this._blastModel.associations;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastModel.prototype, "selected_template_date", {
        get: function () {
            return this._blastModel.selected_template_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastModel.prototype, "status", {
        get: function () {
            return this._blastModel.status;
        },
        enumerable: true,
        configurable: true
    });
    return BlastModel;
}());
Object.seal(BlastModel);
module.exports = BlastModel;
//# sourceMappingURL=BlastModel.js.map