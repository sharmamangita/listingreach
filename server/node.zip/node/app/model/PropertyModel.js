"use strict";
var PropertyModel = (function () {
    function PropertyModel(PropertyModel) {
        this._propertyModel = PropertyModel;
    }
    Object.defineProperty(PropertyModel.prototype, "_id", {
        get: function () {
            return this.propertyModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "blast_id", {
        get: function () {
            return this.propertyModel.blast_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "display_method", {
        get: function () {
            return this.propertyModel.display_method;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "street_address", {
        get: function () {
            return this.propertyModel.street_address;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "city", {
        get: function () {
            return this.propertyModel.city;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "zipcode", {
        get: function () {
            return this.propertyModel.zipcode;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "mls_number", {
        get: function () {
            return this.propertyModel.mls_number;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "propertyImages", {
        get: function () {
            return this.propertyModel.propertyImages;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "board", {
        get: function () {
            return this.propertyModel.board;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "property_type", {
        get: function () {
            return this.propertyModel.property_type;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "property_style", {
        get: function () {
            return this.propertyModel.property_style;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "building_size", {
        get: function () {
            return this.propertyModel.building_size;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "lot_size", {
        get: function () {
            return this.propertyModel.lot_size;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "number_bedrooms", {
        get: function () {
            return this.propertyModel.number_bedrooms;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "year_built", {
        get: function () {
            return this.propertyModel.year_built;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "number_stories", {
        get: function () {
            return this.propertyModel.number_stories;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "garage", {
        get: function () {
            return this.propertyModel.garage;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "price", {
        get: function () {
            return this.propertyModel.garage;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "property_details", {
        get: function () {
            return this.propertyModel.property_details;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "pricingInfo", {
        get: function () {
            return this.propertyModel.pricingInfo;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "number_bathrooms", {
        get: function () {
            return this.propertyModel.number_bathrooms;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "garageSize", {
        get: function () {
            return this.propertyModel.garageSize;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "linksToWebsites", {
        get: function () {
            return this.propertyModel.linksToWebsites;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "isOpenHouse", {
        get: function () {
            return this.propertyModel.isOpenHouse;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(PropertyModel.prototype, "userId", {
        get: function () {
            return this.propertyModel.isOpenHouse;
        },
        enumerable: true,
        configurable: true
    });
    return PropertyModel;
}());
Object.seal(PropertyModel);
module.exports = PropertyModel;
//# sourceMappingURL=PropertyModel.js.map