"use strict";
/**
 * interface for agent model
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ISubscriberModel.js.map