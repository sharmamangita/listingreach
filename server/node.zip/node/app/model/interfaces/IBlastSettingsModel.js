"use strict";
/**
 * interface for Plan model
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IBlastSettingsModel.js.map