"use strict";
/**
 * interface for User model
 */
module.exports = IAgentTemplate;
//# sourceMappingURL=IAgentTemplateModel.js.map