"use strict";
/**
 * interface for User model
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IProfessionalModel.js.map