"use strict";
var AgentModel = (function () {
    function AgentModel(AgentModel) {
        this._agentModel = AgentModel;
    }
    Object.defineProperty(AgentModel.prototype, "_id", {
        get: function () {
            return this._agentModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "user_id", {
        get: function () {
            return this._agentModel.user_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "name", {
        get: function () {
            return this._agentModel.name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "designation", {
        get: function () {
            return this._agentModel.designation;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "email", {
        get: function () {
            return this._agentModel.email;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "website_url", {
        get: function () {
            return this._agentModel.website_url;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "phone_number", {
        get: function () {
            return this._agentModel.phone_number;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "company_details", {
        get: function () {
            return this._agentModel.company_details;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "other_information", {
        get: function () {
            return this._agentModel.other_information;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "image_url", {
        get: function () {
            return this._agentModel.image_url;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "logo_url", {
        get: function () {
            return this._agentModel.logo_url;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "createdOn", {
        get: function () {
            return this._agentModel.createdOn;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "updateOn", {
        get: function () {
            return this._agentModel.updatedOn;
        },
        enumerable: true,
        configurable: true
    });
    return AgentModel;
}());
Object.seal(AgentModel);
module.exports = AgentModel;
//# sourceMappingURL=AgentModel.js.map