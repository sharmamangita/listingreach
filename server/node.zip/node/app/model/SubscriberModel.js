"use strict";
var SubscriberModel = (function () {
    function SubscriberModel(UserModel) {
        this._modal = UserModel;
    }
    Object.defineProperty(SubscriberModel.prototype, "_id", {
        get: function () {
            return this._modal._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "name", {
        get: function () {
            return this._modal.name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "email", {
        get: function () {
            return this._modal.email;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "phone", {
        get: function () {
            return this._modal.phone;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "city", {
        get: function () {
            return this._modal.city;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "state", {
        get: function () {
            return this._modal.state;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "status", {
        get: function () {
            return this._modal.status;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "propertyTypes", {
        get: function () {
            return this._modal.propertyTypes;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "priceRanges", {
        get: function () {
            return this._modal.priceRanges;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "includeRentedProperties", {
        get: function () {
            return this._modal.includeRentedProperties;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "includeOutsideAreaProperties", {
        get: function () {
            return this._modal.includeOutsideAreaProperties;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "agentTypes", {
        get: function () {
            return this._modal.agentTypes;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "mailingLists", {
        get: function () {
            return this._modal.mailingLists;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "createdOn", {
        get: function () {
            return this._modal.createdOn;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SubscriberModel.prototype, "updateOn", {
        get: function () {
            return this._modal.updateOn;
        },
        enumerable: true,
        configurable: true
    });
    return SubscriberModel;
}());
Object.seal(SubscriberModel);
module.exports = SubscriberModel;
//# sourceMappingURL=SubscriberModel.js.map