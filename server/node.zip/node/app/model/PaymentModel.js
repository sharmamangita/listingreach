"use strict";
var AgentModel = (function () {
    function AgentModel(AgentModel) {
        this._paymentModel = PaymentModel;
    }
    Object.defineProperty(AgentModel.prototype, "_id", {
        get: function () {
            return this._paymentModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "invoice_id", {
        get: function () {
            return this._paymentModel.invoice_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "user_id", {
        get: function () {
            return this._paymentModel.user_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "blast_id", {
        get: function () {
            return this._paymentModel.blast_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "paymentID", {
        get: function () {
            return this._paymentModel.paymentID;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "amount", {
        get: function () {
            return this._paymentModel.amount;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "createdOn", {
        get: function () {
            return this._paymentModel.createdOn;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentModel.prototype, "updateOn", {
        get: function () {
            return this._paymentModel.updateOn;
        },
        enumerable: true,
        configurable: true
    });
    return AgentModel;
}());
Object.seal(PaymentModel);
module.exports = PaymentModel;
//# sourceMappingURL=PaymentModel.js.map