"use strict";
var AgentTemplate = (function () {
    function AgentTemplate(AgentTemplateModel) {
        this._agentTemplateModel = AgentTemplateModel;
    }
    Object.defineProperty(AgentTemplate.prototype, "_id", {
        get: function () {
            return this._agentTemplateModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "template_type", {
        get: function () {
            return this._agentTemplateModel.template_type;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "email_subject", {
        get: function () {
            return this._agentTemplateModel.email_subject;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "from_line", {
        get: function () {
            return this._agentTemplateModel.from_line;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "address", {
        get: function () {
            return this._agentTemplateModel.address;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "headline", {
        get: function () {
            return this._agentTemplateModel.headline;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "database_id", {
        get: function () {
            return this._agentTemplateModel.database_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "paid", {
        get: function () {
            return this._agentTemplateModel.paid;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "image_id", {
        get: function () {
            return this._agentTemplateModel.image_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "status", {
        get: function () {
            return this._agentTemplateModel.status;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "Property_id", {
        get: function () {
            return this._agentTemplateModel.Property_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "userId", {
        get: function () {
            return this._agentTemplateModel.Property_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplate.prototype, "created_on", {
        get: function () {
            return this._agentTemplateModel.created_on;
        },
        enumerable: true,
        configurable: true
    });
    return AgentTemplate;
}());
Object.seal(AgentTemplate);
module.exports = AgentTemplate;
//# sourceMappingURL=AgentTemplate.js.map