"use strict";
var AgentTemplateModel = (function () {
    function AgentTemplateModel(AgentTemplateModel) {
        this._agentTemplateModel = AgentTemplateModel;
    }
    Object.defineProperty(AgentTemplateModel.prototype, "_id", {
        get: function () {
            return this._agentTemplateModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "template_type", {
        get: function () {
            return this._agentTemplateModel.template_type;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "email_subject", {
        get: function () {
            return this._agentTemplateModel.email_subject;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "from_line", {
        get: function () {
            return this._agentTemplateModel.from_line;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "address", {
        get: function () {
            return this._agentTemplateModel.address;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "headline", {
        get: function () {
            return this._agentTemplateModel.headline;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "database_id", {
        get: function () {
            return this._agentTemplateModel.database_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "paid", {
        get: function () {
            return this._agentTemplateModel.paid;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "image_id", {
        get: function () {
            return this._agentTemplateModel.image_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "status", {
        get: function () {
            return this._agentTemplateModel.status;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "Property_id", {
        get: function () {
            return this._agentTemplateModel.Property_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "userId", {
        get: function () {
            return this._agentTemplateModel.Property_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AgentTemplateModel.prototype, "created_on", {
        get: function () {
            return this._agentTemplateModel.created_on;
        },
        enumerable: true,
        configurable: true
    });
    return AgentTemplateModel;
}());
Object.seal(AgentTemplateModel);
module.exports = AgentTemplateModel;
//# sourceMappingURL=AgentTemplate.js.map