"use strict";
var BlastImageModel = (function () {
    function BlastImageModel(BlastImageModel) {
        this._blastImageModel = BlastImageModel;
    }
    Object.defineProperty(BlastImageModel.prototype, "_id", {
        get: function () {
            return this._blastImageModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastImageModel.prototype, "user_id", {
        get: function () {
            return this._blastImageModel.user_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastImageModel.prototype, "url", {
        get: function () {
            return this._blastImageModel.blast_type;
        },
        enumerable: true,
        configurable: true
    });
    return BlastImageModel;
}());
Object.seal(BlastImageModel);
module.exports = BlastImageModel;
//# sourceMappingURL=BlastImageModel.js.map