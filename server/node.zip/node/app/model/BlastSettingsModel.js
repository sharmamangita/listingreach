"use strict";
var BlastSettingsModel = (function () {
    function BlastSettingsModel(blastSettingModel) {
        this._blastSettingModel = blastSettingModel;
    }
    Object.defineProperty(BlastSettingsModel.prototype, "_id", {
        get: function () {
            return this._blastSettingModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastSettingsModel.prototype, "per_email_blast_price", {
        get: function () {
            return this._blastSettingModel.per_email_blast_price;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastSettingsModel.prototype, "additional_email_blast_price", {
        get: function () {
            return this._blastSettingModel.additional_email_blast_price;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BlastSettingsModel.prototype, "modifiedOn", {
        get: function () {
            return this._blastSettingModel.modifiedOn;
        },
        enumerable: true,
        configurable: true
    });
    return BlastSettingsModel;
}());
Object.seal(BlastSettingsModel);
module.exports = BlastSettingsModel;
//# sourceMappingURL=BlastSettingsModel.js.map