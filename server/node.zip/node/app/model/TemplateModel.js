"use strict";
var TemplateModel = (function () {
    function TemplateModel(UserModel) {
        this._templateModel = TemplateModel;
    }
    Object.defineProperty(TemplateModel.prototype, "_id", {
        get: function () {
            return this._templateModel._id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "template_type", {
        get: function () {
            return this._templateModel.template_type;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "email_subject", {
        get: function () {
            return this._templateModel.email_subject;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "from_line", {
        get: function () {
            return this._templateModel.from_line;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "address", {
        get: function () {
            return this._templateModel.address;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "headline", {
        get: function () {
            return this._templateModel.headline;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "database_id", {
        get: function () {
            return this._templateModel.database_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "template_date", {
        get: function () {
            return this._templateModel.template_date;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "paid", {
        get: function () {
            return this._templateModel.paid;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "image_id", {
        get: function () {
            return this._templateModel.image_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "status", {
        get: function () {
            return this._templateModel.status;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "Property_id", {
        get: function () {
            return this._templateModel.Property_id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TemplateModel.prototype, "created_on", {
        get: function () {
            return this._templateModel.created_on;
        },
        enumerable: true,
        configurable: true
    });
    return TemplateModel;
}());
Object.seal(TemplateModel);
module.exports = TemplateModel;
//# sourceMappingURL=TemplateModel.js.map