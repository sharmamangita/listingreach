"use strict";
var mongoose = require("mongoose");
var BlastSettingsRepository = require("../repository/BlastSettingsRepository");
var BlastSettingsBusiness = (function () {
    function BlastSettingsBusiness() {
        this._blastSettingsRepository = new BlastSettingsRepository();
    }
    BlastSettingsBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._blastSettingsRepository.create(item, callback);
    };
    BlastSettingsBusiness.prototype.retrieve = function (query, callback) {
        this._blastSettingsRepository.retrieve(query, callback);
    };
    BlastSettingsBusiness.prototype.aggregate = function (query, callback) {
        this._blastSettingsRepository.aggregate(query, callback);
    };
    BlastSettingsBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._blastSettingsRepository.retrieveFields(query, fields, callback);
    };
    BlastSettingsBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._blastSettingsRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._blastSettingsRepository.update(res._id, item, callback);
        });
    };
    BlastSettingsBusiness.prototype.delete = function (_id, callback) {
        this._blastSettingsRepository.delete(_id, callback);
    };
    BlastSettingsBusiness.prototype.deleteMany = function (query, callback) {
        this._blastSettingsRepository.deleteMany(query, callback);
    };
    BlastSettingsBusiness.prototype.findById = function (_id, callback) {
        this._blastSettingsRepository.findById(_id, callback);
    };
    BlastSettingsBusiness.prototype.findOne = function (query, callback) {
        this._blastSettingsRepository.findOne(query, callback);
    };
    BlastSettingsBusiness.prototype.count = function (query, callback) {
        this._blastSettingsRepository.count(query, callback);
    };
    return BlastSettingsBusiness;
}());
Object.seal(BlastSettingsBusiness);
module.exports = BlastSettingsBusiness;
//# sourceMappingURL=BlastSettingsBusiness.js.map