"use strict";
var mongoose = require("mongoose");
var jwt = require('jsonwebtoken');
var _ = require('lodash');
var AgentRepository = require("./../repository/AgentRepository");
var fs = require('fs');
var conversion = require("phantom-html-to-pdf")({
    phantomPath: "/usr/local/bin/phantomjs"
});
var moment = require('moment');
var AgentBusiness = (function () {
    function AgentBusiness() {
        this._agentRepository = new AgentRepository();
    }
    AgentBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._agentRepository.create(item, callback);
    };
    AgentBusiness.prototype.retrieve = function (query, callback) {
        this._agentRepository.retrieve(query, callback);
    };
    AgentBusiness.prototype.aggregate = function (query, callback) {
        this._agentRepository.aggregate(query, callback);
    };
    AgentBusiness.prototype.customaggregate = function (query, match, group, callback) {
        this._agentRepository.customaggregate(query, match, group, callback);
    };
    AgentBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._agentRepository.retrieveFields(query, fields, callback);
    };
    AgentBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._agentRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._agentRepository.update(res._id, item, callback);
        });
    };
    AgentBusiness.prototype.delete = function (_id, callback) {
        this._agentRepository.delete(_id, callback);
    };
    AgentBusiness.prototype.deleteMany = function (query, callback) {
        this._agentRepository.deleteMany(query, callback);
    };
    AgentBusiness.prototype.findById = function (_id, callback) {
        this._agentRepository.findById(_id, callback);
    };
    AgentBusiness.prototype.findOne = function (query, callback) {
        this._agentRepository.findOne(query, callback);
    };
    return AgentBusiness;
}());
Object.seal(AgentBusiness);
module.exports = AgentBusiness;
//# sourceMappingURL=AgentBusiness.js.map