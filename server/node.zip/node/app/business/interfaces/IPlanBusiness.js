"use strict";
/**
 * Interface for User Business Logic */
var IPlanBusiness = require("./../../model/interfaces/IPlanBusiness");
module.exports = IPlanBusiness;
//# sourceMappingURL=IPlanBusiness.js.map