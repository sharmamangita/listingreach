"use strict";
/**
 * Interface for User Business Logic */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IPostreviewBusiness.js.map