"use strict";
/**
 * Interface for User Business Logic */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ISubscriberBusiness.js.map