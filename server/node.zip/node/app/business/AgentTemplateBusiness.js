"use strict";
var mongoose = require("mongoose");
var AgentTemplateRepository = require("./../repository/AgentTemplateRepository");
var AgentTemplateBusiness = (function () {
    function AgentTemplateBusiness() {
        this._agentTemplateRepository = new AgentTemplateRepository();
    }
    AgentTemplateBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._agentTemplateRepository.create(item, callback);
    };
    AgentTemplateBusiness.prototype.retrieve = function (query, callback) {
        this._agentTemplateRepository.retrieve(query, callback);
    };
    AgentTemplateBusiness.prototype.aggregate = function (query, callback) {
        this._agentTemplateRepository.aggregate(query, callback);
    };
    AgentTemplateBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._agentTemplateRepository.retrieveFields(query, fields, callback);
    };
    AgentTemplateBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._agentTemplateRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._agentTemplateRepository.update(res._id, item, callback);
        });
    };
    AgentTemplateBusiness.prototype.delete = function (_id, callback) {
        this._agentTemplateRepository.delete(_id, callback);
    };
    AgentTemplateBusiness.prototype.deleteMany = function (query, callback) {
        this._agentTemplateRepository.deleteMany(query, callback);
    };
    AgentTemplateBusiness.prototype.findById = function (_id, callback) {
        this._agentTemplateRepository.findById(_id, callback);
    };
    AgentTemplateBusiness.prototype.count = function (query, callback) {
        this._agentTemplateRepository.count(query, callback);
    };
    AgentTemplateBusiness.prototype.findOne = function (query, callback) {
        this._agentTemplateRepository.findOne(query, callback);
    };
    return AgentTemplateBusiness;
}());
Object.seal(AgentTemplateBusiness);
module.exports = AgentTemplateBusiness;
//# sourceMappingURL=AgentTemplateBusiness.js.map