"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var mongoose = require("mongoose");
var BlastRepository = require("./../repository/BlastRepository");
var AgentTemplateBusiness = require("./AgentTemplateBusiness");
var PropertyBusiness = require("./PropertyBusiness");
var Common = require("./../../config/constants/common");
var BlastBusiness = (function () {
    function BlastBusiness() {
        this._blastRepository = new BlastRepository();
    }
    BlastBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._blastRepository.create(item, callback);
    };
    BlastBusiness.prototype.retrieve = function (query, callback) {
        this._blastRepository.retrieve(query, callback);
    };
    BlastBusiness.prototype.aggregate = function (query, callback) {
        this._blastRepository.aggregate(query, callback);
    };
    BlastBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._blastRepository.retrieveFields(query, fields, callback);
    };
    BlastBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._blastRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._blastRepository.update(res._id, item, callback);
        });
    };
    BlastBusiness.prototype.delete = function (_id, callback) {
        this._blastRepository.delete(_id, callback);
    };
    BlastBusiness.prototype.deleteMany = function (query, callback) {
        this._blastRepository.deleteMany(query, callback);
    };
    BlastBusiness.prototype.findById = function (_id, callback) {
        this._blastRepository.findById(_id, callback);
    };
    BlastBusiness.prototype.count = function (query, callback) {
        this._blastRepository.count(query, callback);
    };
    BlastBusiness.prototype.findOne = function (query, callback) {
        this._blastRepository.findOne(query, callback);
    };
    BlastBusiness.prototype.getEmailHTML = function (blastId) {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                //   console.log("getting HTML.........", blastId);
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        try {
                            _this._blastRepository.findById(blastId, function (error, blast) {
                                if (error) {
                                    console.log("error geting blast :", error);
                                    reject(error);
                                }
                                ;
                                // console.log("blast",blast);
                                var templateBusiness = new AgentTemplateBusiness();
                                templateBusiness.findById(blast.selected_template_id, function (error, template) {
                                    if (error) {
                                        console.log("error geting template :", error);
                                        reject(error);
                                    }
                                    // console.log("template",template);
                                    var propertyBusiness = new PropertyBusiness();
                                    var query = { blast_id: blast.id };
                                    propertyBusiness.retrieve(query, function (error, properties) {
                                        if (error) {
                                            console.log("error geting properties :", error);
                                            reject(error);
                                        }
                                        //console.log('properties',properties)
                                        var subject = template.email_subject;
                                        var formLine = template.from_line;
                                        var formReply = template.address;
                                        var headline = template.headline;
                                        var agent = blast.agentData;
                                        if (properties && properties.length > 1) {
                                            console.log("multiple properties....");
                                            var html = '';
                                            properties.forEach(function (property) {
                                                html += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;\">\n                                             <div class=\"row\" style=\"display: block;display: flex;flex-wrap: wrap;border-top: 2px solid #ccc;\">\n                                                <div style=\"width:50%;display: block; background:#f1f1f1;height: 400px;\">\n                                                   <img src=\"http://66.235.194.119/listingreach/img/img4.jpg\" alt=\"image\" style=\"width:100%;height: 400px;\">\n                                                </div>";
                                                html += "<div style=\"width:50%;display: block; background:#f1f1f1; height: 400px;\">\n                                                   <div class=\"row\" style=\"display: flex;flex-wrap: wrap;\">\n                                                      <div style=\"width:100%;margin-bottom: 1rem !important; margin-left: 1rem !important;margin-top: 1rem !important;\">\n                                                         <h4 style=\" background: #f1f1f1;font-size: 1.5rem;margin-top: 0;\n                                                            margin-bottom: 1rem;\">Price: " + property.price + " per Square Foot</h4>\n                                                      </div>\n                                                      <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                         <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                            font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Key Features:</label>\n                                                         <ul>\n                                                            <li>Property Type: " + property.property_type + "  </li>\n                                                            <li>Property Style: " + property.property_style + "  </li>\n                                                            <li> " + property.number_bedrooms + " Bedrooms</li>\n                                                            <li>" + property.number_bathrooms[0].full + " Full " + property.number_bathrooms[0].half + " Half Bathrooms</li>\n                                                            <li>1 Full +2 Half Bathrooms</li>\n                                                            <li>" + property.building_size + " square feet</li>\n                                                            <li>" + property.price + "  /sqft</li>\n                                                            <li>Lot Size: " + property.lot_size + " sqft</li>\n                                                            <li>  Built " + property.year_built + " </li>\n                                                            <li>" + property.garageSize + " Garage</li>\n                                                            <li> " + property.number_stories + " </li>\n                                                         </ul>\n                                                      </div>\n                                                   </div>\n                                                </div>\n                                             </div>";
                                                html += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;border-bottom: 2px solid #ccc; padding-top:30px;\">\n                                                <div class=\"row\">\n                                                   <div class=\"mt-3 text-center\" style=\"width:100%;margin-top: 1rem !important;text-align: center !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Address:</label>\n                                                      <p>" + property.street_address + ", " + property.city + ", " + property.zipcode + "</p>\n                                                   </div>";
                                                //                property.isOpenHouse.forEach(function (resut) {
                                                // html += `<div class="text-center" style="width:100%;text-align: center !important;">
                                                //                   <label class="flyer-label" style="color: #EE8C3A;
                                                //                      font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;">${resut.openHouseData}:</label>
                                                //                   <span>${resut.openHouseData.date} ${resut.openHouseData.startTime}  - ${resut.openHouseData.endTime} </span><br>
                                                //                </div>`;
                                                html += "<div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">MLS#:</label>\n                                                      <span>" + property.mls_number + "</span>\n                                                   </div>\n                                                   <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Description:</label>\n                                                      <span>" + property.property_details + "</span>         \n                                                   </div>\n                                                   <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Links:</label>";
                                                property.isOpenHouse.forEach(function (resut) {
                                                    html += "<br><a href=\"http://66.235.194.119/listingreach\" style=\"color: #000000;transition: all .5s ease;\"><u> Websitename with hyperlink</a></u>";
                                                });
                                                html += " </div>\n                                                </div>\n                                             </div>\n                                        </div>";
                                                var previewTemplatememail = Common.PREVIEW_EMAIL_MULTIPROPERTY_TEMPLATE;
                                                var emailtemplate = previewTemplatememail
                                                    .replace(/#multiproperty#/g, html)
                                                    .replace(/#agentName#/g, agent.name)
                                                    .replace(/#agentEmail#/g, agent.email)
                                                    .replace(/#agentImage#/g, agent.image_url || "http://66.235.194.119/listingreach/img/dummy-profile.png")
                                                    .replace(/#companyLogo#/g, agent.logo_url || "http://66.235.194.119/listingreach/img/dummy-logo.png")
                                                    .replace(/#WebsiteUrl#/g, agent.website_url)
                                                    .replace(/#phone_number#/g, agent.phone_number)
                                                    .replace(/#companyDetail#/g, agent.company_details)
                                                    .replace(/#subject#/g, subject)
                                                    .replace(/#formLine#/g, formLine)
                                                    .replace(/#formReply#/g, formReply)
                                                    .replace(/#blastHeadline#/g, headline);
                                                resolve(emailtemplate);
                                            });
                                        }
                                        else {
                                            console.log("single property....");
                                            var html_1 = '';
                                            properties.forEach(function (property) {
                                                //  console.log("property",property);
                                                html_1 += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;\">\n                                             <div class=\"row\" style=\"display: block;display: flex;flex-wrap: wrap;border-top: 2px solid #ccc;\">\n                                                <div style=\"width:50%;display: block; background:#f1f1f1;height: 400px;\">\n                                                   <img src=\"http://66.235.194.119/listingreach/img/img4.jpg\" alt=\"image\" style=\"width:100%;height: 400px;\">\n                                                </div>";
                                                html_1 += "<div style=\"width:50%;display: block; background:#f1f1f1; height: 400px;\">\n                                                   <div class=\"row\" style=\"display: flex;flex-wrap: wrap;\">\n                                                      <div style=\"width:100%;margin-bottom: 1rem !important; margin-left: 1rem !important;margin-top: 1rem !important;\">\n                                                         <h4 style=\" background: #f1f1f1;font-size: 1.5rem;margin-top: 0;\n                                                            margin-bottom: 1rem;\">Price: " + property.price + " per Square Foot</h4>\n                                                      </div>\n                                                      <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                         <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                            font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Key Features:</label>\n                                                         <ul>\n                                                            <li>Property Type: " + property.property_type + "  </li>\n                                                            <li>Property Style: " + property.property_style + "  </li>\n                                                            <li> " + property.number_bedrooms + " Bedrooms</li>\n                                                            <li>" + property.number_bathrooms[0].full + " Full " + property.number_bathrooms[0].half + " Half Bathrooms</li>\n                                                            <li>1 Full +2 Half Bathrooms</li>\n                                                            <li>" + property.building_size + " square feet</li>\n                                                            <li>" + property.price + "  /sqft</li>\n                                                            <li>Lot Size: " + property.lot_size + " sqft</li>\n                                                            <li>  Built " + property.year_built + " </li>\n                                                            <li>" + property.garageSize + " Garage</li>\n                                                            <li> " + property.number_stories + " </li>\n                                                         </ul>\n                                                      </div>\n                                                   </div>\n                                                </div>\n                                             </div>";
                                                html_1 += "<div class=\"flyer-bg\" style=\"background: #f1f1f1;border-bottom: 2px solid #ccc; padding-top:30px;\">\n                                                <div class=\"row\">\n                                                   <div class=\"mt-3 text-center\" style=\"width:100%;margin-top: 1rem !important;text-align: center !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Address:</label>\n                                                      <p>" + property.street_address + ", " + property.city + ", " + property.zipcode + "</p>\n                                                   </div>";
                                                property.isOpenHouse.forEach(function (resut) {
                                                    // html += `<div class="text-center" style="width:100%;text-align: center !important;">
                                                    //                   <label class="flyer-label" style="color: #EE8C3A;
                                                    //                      font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;">${resut.openHouseData.houseType}:</label>
                                                    //                   <span>${resut.openHouseData.date} ${resut.openHouseData.startTime}  - ${resut.openHouseData.endTime} </span><br>
                                                    //                </div>`;
                                                });
                                                html_1 += "<div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">MLS#:</label>\n                                                      <span>" + property.mls_number + "</span>\n                                                   </div>\n                                                   <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Property Description:</label>\n                                                      <span>" + property.property_details + "</span>         \n                                                   </div>\n                                                   <div class=\"ml-3\" style=\"width:100%; margin-left: 1rem !important;\">\n                                                      <label class=\"flyer-label\" style=\"color: #EE8C3A;\n                                                         font-size: 1rem;display: inline-block;margin-bottom: 0.5rem;\">Links:</label>";
                                                property.isOpenHouse.forEach(function (resut) {
                                                    html_1 += "<br><a href=\"http://66.235.194.119/listingreach\" style=\"color: #000000;transition: all .5s ease;\"><u> Websitename with hyperlink</a></u>";
                                                });
                                                html_1 += " </div>\n                                                </div>\n                                             </div>\n                                        </div>";
                                                var previewTemplatememail = Common.PREVIEW_EMAIL_MULTIPROPERTY_TEMPLATE;
                                                var emailtemplate = previewTemplatememail
                                                    .replace(/#multiproperty#/g, html_1)
                                                    .replace(/#agentName#/g, agent.name)
                                                    .replace(/#agentEmail#/g, agent.email)
                                                    .replace(/#agentImage#/g, agent.image_url || "http://66.235.194.119/listingreach/img/dummy-profile.png")
                                                    .replace(/#companyLogo#/g, agent.logo_url)
                                                    .replace(/#WebsiteUrl#/g, agent.website_url)
                                                    .replace(/#subject#/g, subject)
                                                    .replace(/#formLine#/g, formLine)
                                                    .replace(/#formReply#/g, formReply)
                                                    .replace(/#blastHeadline#/g, headline);
                                                //} 
                                                // else {
                                                //     let openData = '';
                                                //     if (property[0].isOpenHouse.openHouseData != undefined && property[0].isOpenHouse.openHouseData.length) {
                                                //         let houseArray = property[0].isOpenHouse.openHouseData;
                                                //         //console.log("houseArray===",houseArray);
                                                //         houseArray.forEach(function (item) {
                                                //             openData += `<div>
                                                //      <label class="flyer-label">${item.openHouseData.houseType}:</label>
                                                //      <span>${item.openHouseData.date} ${item.openHouseData.startTime}  - ${item.openHouseData.endTime}</span><br>
                                                //      </div>`;
                                                //         })
                                                //     }
                                                //     let links = '';
                                                //     if (property[0].linksToWebsites.linkData != undefined && property[0].linksToWebsites.linkData.length) {
                                                //         let linkArray = property[0].linksToWebsites.linkData;
                                                //         linkArray.forEach(function (item) {
                                                //             links += `<div>
                                                //       <label class="flyer-label">Links:</label>
                                                //          <p><a href="#"><u> ${item.linksToWebsiteData.buildingSize}</a></u></p><br>
                                                //      </div>`;
                                                //         })
                                                //     }
                                                //     var previewTemplatememail = Common.PREVIEW_EMAIL_TEMPLATE;
                                                //     var emailtemplate = previewTemplatememail
                                                //         .replace(/#subject#/g, subject)
                                                //         .replace(/#formLine#/g, formLine)
                                                //         .replace(/#formReply#/g, formReply)
                                                //         .replace(/#blastHeadline#/g, headline)
                                                //         .replace(/#numberOfBedrooms#/g, property[0].numberOfBedrooms)
                                                //         .replace(/#propertyDetail#/g, property[0].propertyDetail)
                                                //         .replace(/#mlsNumber#/g, property[0].mlsNumber)
                                                //         .replace(/#streetAddress#/g, property[0].streetAddress)
                                                //         .replace(/#zipCode#/g, property[0].zipCode)
                                                //         .replace(/#city#/g, property[0].city)
                                                //         .replace(/#pricePerSquareFoot#/g, property[0].pricePerSquareFoot)
                                                //         .replace(/#yearBuilt#/g, property[0].yearBuilt)
                                                //         .replace(/#lotSize#/g, property[0].lotSize)
                                                //         .replace(/#openData#/g, openData)
                                                //         .replace(/#links#/g, links)
                                                //         .replace(/#propertyType#/g, property[0].propertyType)
                                                //         .replace(/#full#/g, property[0].number_bathrooms[0].full)
                                                //         .replace(/#half#/g, property[0].number_bathrooms[0].half)
                                                //         .replace(/#garageSize#/g, property[0].garageSize)
                                                //         .replace(/#propertyStyle#/g, property[0].propertyStyle)
                                                //         .replace(/#numberOfStories#/g, property[0].numberOfStories)
                                                //         .replace(/#agentName#/g, agentData.name)
                                                //         .replace(/#agentEmail#/g, agentData.Email)
                                                //         .replace(/#agentImage#/g, agentData.image_url || "http://66.235.194.119/listingreach/img/dummy-profile.png")
                                                //         .replace(/#companyLogo#/g, agentData.logo_url || "http://66.235.194.119/listingreach/img/dummy-logo.png")
                                                //         .replace(/#WebsiteUrl#/g, agentData.website_url)
                                                //         .replace(/#phone_number#/g, agentData.phone_number)
                                                //         .replace(/#companyDetail#/g, agentData.company_details);
                                                //     Common.sendMail(property.email, 'support@employeemirror.com', 'Property Details', null, emailtemplate, function (error: any, response: any) {
                                                //         if (error) {
                                                //             console.log(error);
                                                //             res.end("error");
                                                //         }
                                                //     });
                                                //     res.status(201).send({ "success": "done" });
                                                // }                              
                                                resolve(emailtemplate);
                                            });
                                        }
                                        ;
                                    });
                                });
                            });
                            //  return null;
                        }
                        catch (e) {
                            console.log("Email Generate Exception", e);
                            reject(e);
                        }
                    })];
            });
        });
    };
    return BlastBusiness;
}());
Object.seal(BlastBusiness);
module.exports = BlastBusiness;
//# sourceMappingURL=BlastBusiness.js.map