"use strict";
var SubscriberRepository = require("../repository/SubscriberRepository");
var mongoose = require("mongoose");
var SubscriberBusiness = (function () {
    function SubscriberBusiness() {
        this._subscriberRepository = new SubscriberRepository();
    }
    SubscriberBusiness.prototype.retrieve = function (query, callback) {
        this._subscriberRepository.retrieve(query, callback);
    };
    SubscriberBusiness.prototype.count = function (query, callback) {
        this._subscriberRepository.count(query, callback);
    };
    SubscriberBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._subscriberRepository.retrieveFields(query, fields, callback);
    };
    SubscriberBusiness.prototype.customaggregate = function (query, match, group, callback) {
        this._subscriberRepository.customaggregate(query, match, group, callback);
    };
    SubscriberBusiness.prototype.aggregate = function (query, callback) {
        this._subscriberRepository.aggregate(query, callback);
    };
    SubscriberBusiness.prototype.findOne = function (query, callback) {
        this._subscriberRepository.findOne(query, callback);
    };
    SubscriberBusiness.prototype.findById = function (_id, callback) {
        this._subscriberRepository.findById(_id, callback);
    };
    SubscriberBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._subscriberRepository.create(item, callback);
    };
    ;
    SubscriberBusiness.prototype.update = function (_id, item, callback) {
        this._subscriberRepository.update(item._id, item, callback);
    };
    SubscriberBusiness.prototype.delete = function (_id, callback) {
        this._subscriberRepository.delete(_id, callback);
    };
    return SubscriberBusiness;
}());
Object.seal(SubscriberBusiness);
module.exports = SubscriberBusiness;
//# sourceMappingURL=SubscriberBusiness.js.map