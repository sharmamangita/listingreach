"use strict";
var mongoose = require("mongoose");
var PaymentRepository = require("./../repository/PaymentRepository");
var PaymentBusiness = (function () {
    function PaymentBusiness() {
        this._paymentRepository = new PaymentRepository();
    }
    PaymentBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._paymentRepository.create(item, callback);
    };
    PaymentBusiness.prototype.retrieve = function (query, callback) {
        this._paymentRepository.retrieve(query, callback);
    };
    PaymentBusiness.prototype.aggregate = function (query, callback) {
        this._paymentRepository.aggregate(query, callback);
    };
    PaymentBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._paymentRepository.retrieveFields(query, fields, callback);
    };
    PaymentBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._paymentRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._paymentRepository.update(res._id, item, callback);
        });
    };
    PaymentBusiness.prototype.delete = function (_id, callback) {
        this._paymentRepository.delete(_id, callback);
    };
    PaymentBusiness.prototype.deleteMany = function (query, callback) {
        this._paymentRepository.deleteMany(query, callback);
    };
    PaymentBusiness.prototype.findById = function (_id, callback) {
        this._paymentRepository.findById(_id, callback);
    };
    PaymentBusiness.prototype.count = function (query, callback) {
        this._paymentRepository.count(query, callback);
    };
    PaymentBusiness.prototype.findOne = function (query, callback) {
        this._paymentRepository.findOne(query, callback);
    };
    return PaymentBusiness;
}());
Object.seal(PaymentBusiness);
module.exports = PaymentBusiness;
//# sourceMappingURL=PaymentBusiness.js.map