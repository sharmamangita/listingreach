"use strict";
var mongoose = require("mongoose");
var BlastImageRepository = require("./../repository/BlastImageRepository");
var BlastImageBusiness = (function () {
    function BlastImageBusiness() {
        this._blastImageRepository = new BlastImageRepository();
    }
    BlastImageBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._blastImageRepository.create(item, callback);
    };
    BlastImageBusiness.prototype.retrieve = function (query, callback) {
        this._blastImageRepository.retrieve(query, callback);
    };
    BlastImageBusiness.prototype.aggregate = function (query, callback) {
        this._blastImageRepository.aggregate(query, callback);
    };
    BlastImageBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._blastImageRepository.retrieveFields(query, fields, callback);
    };
    BlastImageBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._blastImageRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._blastImageRepository.update(res._id, item, callback);
        });
    };
    BlastImageBusiness.prototype.delete = function (_id, callback) {
        this._blastImageRepository.delete(_id, callback);
    };
    BlastImageBusiness.prototype.deleteMany = function (query, callback) {
        this._blastImageRepository.deleteMany(query, callback);
    };
    BlastImageBusiness.prototype.findById = function (_id, callback) {
        this._blastImageRepository.findById(_id, callback);
    };
    BlastImageBusiness.prototype.count = function (query, callback) {
        this._blastImageRepository.count(query, callback);
    };
    BlastImageBusiness.prototype.findOne = function (query, callback) {
        this._blastImageRepository.findOne(query, callback);
    };
    return BlastImageBusiness;
}());
Object.seal(BlastImageBusiness);
module.exports = BlastImageBusiness;
//# sourceMappingURL=BlastImageBusiness.js.map