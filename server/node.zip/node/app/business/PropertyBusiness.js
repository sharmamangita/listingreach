"use strict";
var mongoose = require("mongoose");
var PropertyRepository = require("./../repository/PropertyRepository");
var PropertyBusiness = (function () {
    function PropertyBusiness() {
        this._propertyRepository = new PropertyRepository();
    }
    PropertyBusiness.prototype.create = function (item, callback) {
        item._id = mongoose.Types.ObjectId();
        this._propertyRepository.create(item, callback);
    };
    PropertyBusiness.prototype.retrieve = function (query, callback) {
        this._propertyRepository.retrieve(query, callback);
    };
    PropertyBusiness.prototype.aggregate = function (query, callback) {
        this._propertyRepository.aggregate(query, callback);
    };
    PropertyBusiness.prototype.retrieveFields = function (query, fields, callback) {
        this._propertyRepository.retrieveFields(query, fields, callback);
    };
    PropertyBusiness.prototype.update = function (_id, item, callback) {
        var _this = this;
        this._propertyRepository.findById(_id, function (err, res) {
            if (err)
                callback(err, res);
            else
                _this._propertyRepository.update(res._id, item, callback);
        });
    };
    PropertyBusiness.prototype.delete = function (_id, callback) {
        this._propertyRepository.delete(_id, callback);
    };
    PropertyBusiness.prototype.deleteMany = function (query, callback) {
        this._propertyRepository.deleteMany(query, callback);
    };
    PropertyBusiness.prototype.findById = function (_id, callback) {
        this._propertyRepository.findById(_id, callback);
    };
    PropertyBusiness.prototype.count = function (query, callback) {
        this._propertyRepository.count(query, callback);
    };
    PropertyBusiness.prototype.findOne = function (query, callback) {
        this._propertyRepository.findOne(query, callback);
    };
    return PropertyBusiness;
}());
Object.seal(PropertyBusiness);
module.exports = PropertyBusiness;
//# sourceMappingURL=PropertyBusiness.js.map