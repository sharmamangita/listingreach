"use strict";
/**
 * company schema for collections: companies
 */
var DataAccess = require("../DataAccess");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var PaymentSchema = (function () {
    function PaymentSchema() {
    }
    Object.defineProperty(PaymentSchema, "schema", {
        get: function () {
            var schema = mongoose.Schema({
                _id: mongoose.Schema.Types.ObjectId,
                user_id: {
                    type: mongoose.Schema.Types.ObjectId,
                    required: true
                },
                blast_id: {
                    type: mongoose.Schema.Types.ObjectId,
                    required: true
                },
                invoice_id: {
                    type: String
                },
                paymentID: {
                    type: String,
                    required: true
                },
                amount: {
                    type: Number,
                    required: true
                },
                createdOn: {
                    type: Date,
                    required: true
                },
                updateOn: {
                    type: Date
                }
            });
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return PaymentSchema;
}());
// we need to create a model using it
var PaymentModel = mongooseConnection.model("payment", PaymentSchema.schema);
module.exports = PaymentModel;
//# sourceMappingURL=PaymentSchema.js.map