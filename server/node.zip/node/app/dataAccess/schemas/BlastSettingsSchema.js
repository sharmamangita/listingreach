"use strict";
/**
 * company schema for collections: companies
 */
var DataAccess = require("../DataAccess");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var BlastSettingsSchema = (function () {
    function BlastSettingsSchema() {
    }
    Object.defineProperty(BlastSettingsSchema, "schema", {
        get: function () {
            var schema = mongoose.Schema({
                per_email_blast_price: {
                    type: Number,
                    required: true
                },
                additional_email_blast_price: {
                    type: Number
                },
                modifiedOn: {
                    type: Date,
                    required: true
                },
            });
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return BlastSettingsSchema;
}());
// we need to create a model using it
var BlastSettingsModel = mongooseConnection.model("Blast_Settings", BlastSettingsSchema.schema);
module.exports = BlastSettingsModel;
//# sourceMappingURL=BlastSettingsSchema.js.map