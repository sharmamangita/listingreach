"use strict";
/**
 * company schema for collections: companies
 */
var DataAccess = require("../DataAccess");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var PropertySchema = (function () {
    function PropertySchema() {
    }
    Object.defineProperty(PropertySchema, "schema", {
        get: function () {
            var schema = mongoose.Schema({
                _id: mongoose.Schema.Types.ObjectId,
                blast_id: {
                    type: mongoose.Schema.Types.ObjectId
                },
                display_method: {
                    type: String
                },
                street_address: {
                    type: String
                },
                city: {
                    type: String
                },
                state: {
                    type: String
                },
                zipcode: {
                    type: String
                },
                mls_number: {
                    type: String
                },
                board: {
                    type: String
                },
                property_type: {
                    type: String
                },
                property_style: {
                    type: String
                },
                building_size: {
                    type: String
                },
                lot_size: {
                    type: String
                },
                number_bedrooms: {
                    type: String
                },
                year_built: {
                    type: String
                },
                number_stories: {
                    type: String
                },
                garage: {
                    type: String
                },
                property_details: {
                    type: String
                },
                price: {
                    type: String
                },
                garageSize: {
                    type: String
                },
                pricingInfo: [{
                        price: {
                            type: String
                        },
                        priceType: {
                            type: String
                        }
                    }],
                number_bathrooms: [{
                        full: {
                            type: String
                        },
                        half: {
                            type: String
                        }
                    }],
                linksToWebsites: [{
                        text: { type: String },
                        url: { type: String }
                    }],
                isOpenHouse: [{
                        houseType: { type: String },
                        date: { type: Date },
                        startTime: { type: String },
                        endTime: { type: String }
                    }],
                userId: {
                    type: mongoose.Schema.Types.ObjectId
                },
                propertyImages: [{
                        imageId: { type: String },
                        imageUrl: { type: String }
                    }],
            });
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return PropertySchema;
}());
// we need to create a model using it
var PropertyModel = mongooseConnection.model("property", PropertySchema.schema);
module.exports = PropertyModel;
//# sourceMappingURL=PropertySchema.js.map