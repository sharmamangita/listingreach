"use strict";
/**
 * company schema for collections: companies
 */
var DataAccess = require("../DataAccess");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var UserSchema = (function () {
    function UserSchema() {
    }
    Object.defineProperty(UserSchema, "schema", {
        get: function () {
            var schema = mongoose.Schema({
                _id: mongoose.Schema.Types.ObjectId,
                firstName: {
                    type: String,
                    required: true
                },
                lastName: {
                    type: String,
                    required: true
                },
                middleName: {
                    type: String
                },
                email: {
                    type: String,
                    required: true,
                    unique: true
                },
                password: {
                    type: String
                },
                userName: {
                    type: String,
                    required: true
                },
                roles: {
                    type: String,
                    required: true
                },
                companyName: {
                    type: String,
                },
                phone: {
                    type: String,
                },
                city: {
                    type: String,
                },
                country: {
                    type: String,
                },
                zipcode: {
                    type: String,
                },
                state: {
                    type: String,
                },
                lastLogin: {
                    type: Date
                },
                token: {
                    type: String
                },
                status: {
                    type: String
                },
                paidOn: {
                    type: Boolean
                },
                createdOn: {
                    type: Date,
                    required: true
                },
                isDeleted: {
                    type: Boolean,
                },
            });
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return UserSchema;
}());
// we need to create a model using it
var UserModel = mongooseConnection.model("Users", UserSchema.schema);
module.exports = UserModel;
//# sourceMappingURL=UserSchema.js.map