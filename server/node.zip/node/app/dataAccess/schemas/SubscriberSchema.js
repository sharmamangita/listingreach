"use strict";
var DataAccess = require("../DataAccess");
var mongo = require("mongoose");
var mongoose = DataAccess.mongooseInstance;
var mongooseConnection = DataAccess.mongooseConnection;
var SubscriberSchema = (function () {
    function SubscriberSchema() {
    }
    Object.defineProperty(SubscriberSchema, "schema", {
        get: function () {
            var schema = mongoose.Schema({
                _id: mongo.Schema.Types.ObjectId,
                name: {
                    type: String,
                    required: true
                },
                email: {
                    type: String,
                    required: true,
                    unique: true
                },
                phone: {
                    type: String
                },
                city: {
                    type: String
                },
                state: {
                    type: String
                },
                status: {
                    type: String,
                    required: true
                },
                propertyTypes: {
                    type: [String],
                    required: true
                },
                priceRanges: [{
                        text: { type: String },
                        min: { type: Number },
                        max: { type: Number }
                    }],
                includeRentedProperties: {
                    type: Boolean,
                    default: false
                },
                includeOutsideAreaProperties: {
                    type: Boolean,
                    default: true
                },
                agentTypes: {
                    type: [String]
                },
                mailingLists: {
                    type: [],
                    required: true
                },
                createdOn: {
                    type: Date,
                    required: true
                },
                updateOn: {
                    type: Date
                }
            }, { _id: false });
            return schema;
        },
        enumerable: true,
        configurable: true
    });
    return SubscriberSchema;
}());
// we need to create a model using it
var SubscriberModal = mongooseConnection.model("Subscribers", SubscriberSchema.schema);
module.exports = SubscriberModal;
//# sourceMappingURL=SubscriberSchema.js.map