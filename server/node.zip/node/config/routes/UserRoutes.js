"use strict";
/**
 * User related routes
 */
var express = require("express");
var UserController = require("./../../controllers/UserController");
var router = express.Router();
var UserRoutes = (function () {
    function UserRoutes() {
        this._userController = new UserController();
    }
    Object.defineProperty(UserRoutes.prototype, "routes", {
        get: function () {
            var controller = this._userController;
            router.get("/users", controller.retrieve);
            router.post("/users", controller.create);
            router.get("/users/:_id", controller.findById);
            router.get("/users-bytoken", controller.findByToken);
            router.get("/users/getEmailExists/:query", controller.getEmailExists);
            router.post("/users/register", controller.register);
            router.post("/users/authenticate", controller.authenticate);
            router.post("/users/verifytoken", controller.verifytoken);
            router.delete("/users/:_id/:_flag", controller.delete);
            router.post("/users/forgetUserPassword", controller.forgetUserPassword);
            router.post("/users/forgetSAdminPassword", controller.forgetSAdminPassword);
            router.post("/users/contactForm", controller.contactForm);
            router.post("/users/emailPreviewTemplate", controller.emailPreviewTemplate);
            router.post("/users/UpdateUserPassword", controller.UpdateUserPassword);
            router.put("/userUpdate", controller.updateUser);
            router.post("/users/getReferences", controller.getReferences);
            router.post("/users/saveAgents", controller.saveAgents);
            router.post("/users/savePayment/:blastId", controller.savePayment);
            router.get("/users/getPayment/:_id", controller.getPayment);
            router.post("/saveBlastCalender/:blastId", controller.saveBlastCalender);
            /* blast routes */
            router.post("/users/selectDatabase", controller.selectDatabase);
            router.post("/users/saveBlast", controller.saveBlast);
            router.post("/users/saveDesignTemplate", controller.saveDesignTemplate);
            router.post("/users/saveProperty", controller.saveProperty);
            router.post("/users/propertyDetail", controller.getTemplateOrPropertydata);
            router.get("/users/getSavedBlast/:agentId", controller.getSavedBlast);
            router.get("/users/deleteSavedBlast/:id", controller.deleteSavedBlast);
            router.post("/users/saveImages", controller.saveImages);
            router.post("/saveBlastCalender/:blastId", controller.saveBlastCalender);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return UserRoutes;
}());
Object.seal(UserRoutes);
module.exports = UserRoutes;
//# sourceMappingURL=UserRoutes.js.map