"use strict";
/**
 * User related routes
 */
var express = require("express");
var AdminUserController = require("./../../controllers/AdminUserController");
var router = express.Router();
var AdminUserRoutes = (function () {
    function AdminUserRoutes() {
        this._adminUserController = new AdminUserController();
    }
    Object.defineProperty(AdminUserRoutes.prototype, "routes", {
        get: function () {
            var controller = this._adminUserController;
            //  router.get("/adminusers/plan",controller.getPlans);
            router.get("/adminusers/blastsettings", controller.getBlastSettings);
            router.put("/adminuser/updateblastsettings", controller.updateBlastSetings);
            router.get("/adminusers/getContent", controller.getContent);
            router.get("/adminusers/agents", controller.getAgents);
            router.get("/adminusers/payments", controller.getPayments);
            router.get("/adminusers/subscribers", controller.getSubscribers);
            router.get("/adminusers/blasts", controller.getBlasts);
            router.get("/adminuser/sendblast/:id", controller.sendBlast);
            router.get("/adminusers/activecampaignassociations", controller.getActiveCampaignAssociations);
            router.put("/adminusers/", controller.update);
            router.delete("/adminusers/:_id", controller.deleteusers);
            router.put("/adminusers/deleteagents/:_id", controller.deleteagents);
            router.get("/userStatus/:_id", controller.userStatus);
            router.get("/adminuser/subscriberstatus/:_id", controller.changeSubscriberStatus);
            router.get("/adminusers/:_id", controller.findById);
            router.get("/adminusers/counts/:flag", controller.getCount);
            router.get("/adminusers-bytoken", controller.findByToken);
            router.get("/adminusers-get-billing-detail", controller.getBillingDetail);
            router.get("/adminusers/count/:query", controller.count);
            router.post("/adminusers/authenticate", controller.authenticate);
            router.post("/adminusers/verifytoken", controller.verifytoken);
            router.put("/adminusers/change-password", controller.changePassword);
            router.post("/adminusers/updateContent", controller.updateContent);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return AdminUserRoutes;
}());
Object.seal(AdminUserRoutes);
module.exports = AdminUserRoutes;
//# sourceMappingURL=AdminUserRoutes.js.map