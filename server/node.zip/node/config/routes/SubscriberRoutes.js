"use strict";
var express = require("express");
var SubscriberController = require("./../../controllers/SubscriberController");
var router = express.Router();
var SubscriberRoutes = (function () {
    function SubscriberRoutes() {
        this._controller = new SubscriberController();
    }
    Object.defineProperty(SubscriberRoutes.prototype, "routes", {
        get: function () {
            var controller = this._controller;
            console.log("in common routes");
            router.post("/subscriber/register", controller.create);
            router.get("/subscriber/getagentdatabase/:state", controller.getAgentDatabase);
            router.get("/subscriber/preferences/:id", controller.getSubsciberPreferences);
            return router;
        },
        enumerable: true,
        configurable: true
    });
    return SubscriberRoutes;
}());
Object.seal(SubscriberRoutes);
module.exports = SubscriberRoutes;
//# sourceMappingURL=SubscriberRoutes.js.map